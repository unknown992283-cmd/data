/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { 
  User, Wallet, EarningSummary, Transaction, WithdrawalRequest, 
  Referral, VIPPlan, RewardState, NetworkSession, NotificationItem, 
  ActivityLog, PricingConfig, AdminSettings, WithdrawMethod, SpeedPlan
} from "./src/types";

// In-Memory Database State
const USERS: Map<string, User> = new Map();
const WALLETS: Map<string, Wallet> = new Map();
const EARNINGS: Map<string, EarningSummary> = new Map();
const TRANSACTIONS: Transaction[] = [];
const WITHDRAWALS: WithdrawalRequest[] = [];
const REFERRALS: Referral[] = [];
const SESSIONS: Map<string, NetworkSession> = new Map();
const NOTIFICATIONS: NotificationItem[] = [];
const ACTIVITY_LOGS: ActivityLog[] = [];
const REWARD_STATES: Map<string, RewardState> = new Map();

// Default Configurations
let PRICING: PricingConfig = {
  perMbPriceUsd: 0.00015, // $0.00015 per MB ($0.15 per GB)
  perGbPriceUsd: 0.15,
  referralCommissionPercent: 12, // 12% commission
  baseWeeklyReward: 0.50, // $0.50 weekly bonuses
};

let ADMIN_SETTINGS: AdminSettings = {
  banners: [
    { id: "b1", title: "Earn 15% extra rewards this week by upgrading to Gold VIP!", url: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=600&auto=format&fit=crop", active: true },
    { id: "b2", title: "DataEarn Pro hits 50,000 active sharing nodes in South Asia!", url: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=600&auto=format&fit=crop", active: true }
  ],
  announcements: [
    { id: "a1", content: "Withdrawals via bKash & Nagad are taking up to 2 hours today due to system maintenance.", active: true },
    { id: "a2", content: "Tip: Keep the server connection active on high-speed WiFi for optimal earnings multiplier.", active: true }
  ],
  fraudThresholdGb: 40 // flag devices logging > 40GB a day
};

// Available VIP categories
const VIP_PLANS: VIPPlan[] = [
  { id: "bronze", name: "Bronze Level", minDataShared: 0, multiplier: 1.0, perGbRate: 0.15, iconName: "Award", color: "#CD7F32", priceUsd: 0 },
  { id: "silver", name: "Silver Share", minDataShared: 50, multiplier: 1.25, perGbRate: 0.1875, iconName: "ShieldCheck", color: "#C0C0C0", priceUsd: 3.00 },
  { id: "gold", name: "Gold Node", minDataShared: 250, multiplier: 1.6, perGbRate: 0.24, iconName: "Flame", color: "#FFD700", priceUsd: 10.00 },
  { id: "diamond", name: "Diamond Enterprise", minDataShared: 1000, multiplier: 2.2, perGbRate: 0.33, iconName: "Gem", color: "#B9F2FF", priceUsd: 25.00 },
];

// Available Speed upgrade levels ("koto speed a mb nibe seta buy kora jabe, first a 1 Mbps thakbe")
const SPEED_PLANS: SpeedPlan[] = [
  { id: "speed_1", name: "Basic speed", speedMbps: 1, priceUsd: 0.00, color: "border-slate-700/60 bg-slate-800/10 text-slate-400", description: "Default starter priority route" },
  { id: "speed_5", name: "Starter Boost", speedMbps: 5, priceUsd: 2.00, color: "border-blue-500/30 bg-blue-500/5 text-blue-400", description: "5 Mbps upload pipelines" },
  { id: "speed_10", name: "Turbo Node", speedMbps: 10, priceUsd: 4.50, color: "border-teal-500/30 bg-teal-500/5 text-teal-400", description: "10 Mbps high frequency stream" },
  { id: "speed_25", name: "Supercharger", speedMbps: 25, priceUsd: 8.00, color: "border-amber-500/30 bg-amber-500/5 text-amber-400", description: "25 Mbps rapid carrier pipelines" },
  { id: "speed_50", name: "Hyper Drive Pro", speedMbps: 50, priceUsd: 15.00, color: "border-pink-500/30 bg-pink-500/5 text-pink-400", description: "50 Mbps latency reduction priority" },
  { id: "speed_100", name: "Quantum Speed", speedMbps: 100, priceUsd: 25.00, color: "border-cyan-500/30 bg-cyan-500/5 text-cyan-400", description: "100 Mbps career-grade extreme upload" },
];

// Helper to pre-populate database with elegant sample data
function preseedDatabase() {
  // Create sample admin
  const adminUser: User = {
    id: "admin1",
    phone: "01781113140",
    email: "admin@dataearn.pro",
    name: "System Director",
    role: "admin",
    vipPlanId: "diamond",
    referralCode: "ADMINPRO",
    createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(),
    status: "active",
    deviceInfo: "Apple MacBook Pro M3 Max",
    lastLogin: new Date().toISOString()
  };
  USERS.set(adminUser.id, adminUser);
  USERS.set(adminUser.email, adminUser);
  USERS.set(adminUser.phone, adminUser);
  USERS.set("+8801781113140", adminUser);

  // Set up Admin's wallet and basic node
  WALLETS.set(adminUser.id, {
    userId: adminUser.id,
    mainBalance: 0.00,
    pendingBalance: 0.00,
    withdrawableBalance: 0.00
  });

  EARNINGS.set(adminUser.id, {
    userId: adminUser.id,
    todayEarnings: 0.00,
    totalEarnings: 0.00,
    totalSharedData: 0.00,
    dailyEarnings: {},
    weeklyEarnings: {},
    monthlyEarnings: {}
  });

  REWARD_STATES.set(adminUser.id, {
    userId: adminUser.id,
    spinsRemaining: 3,
    spinCountToday: 0
  });

  // Global Notifications/Announcements
  NOTIFICATIONS.push(
    { id: "n1", userId: "all", title: "System Ready", message: "DataEarn Pro node system is live. Sign up to build your device calibration network.", type: "info", isRead: false, createdAt: new Date().toISOString() }
  );
}

// Initialise DB
preseedDatabase();

async function startServer() {
  const app = express();
  app.use(express.json());

  // Log active state logging
  console.log("DataEarn Pro Database pre-seeded successfully");

  // Authentication Middleware Mock-JWT (we keep simple token headers representing user IDs for robustness)
  function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized access. No session token provided." });
    }
    const token = authHeader.split(" ")[1];
    const user = USERS.get(token);
    if (!user) {
      return res.status(401).json({ error: "Invalid session token. Please log in again." });
    }
    if (user.status === "banned") {
      return res.status(403).json({ error: "This device is banned due to network sharing violations." });
    }
    (req as any).user = user;
    next();
  }

  // Admin Middleware Role Verification
  function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
    requireAuth(req, res, () => {
      const user = (req as any).user as User;
      if (user.role !== "admin") {
        return res.status(403).json({ error: "Access Denied. Administrator privileges required." });
      }
      next();
    });
  }

  // --- REST API ENDPOINTS ---

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "online", usersSeeded: USERS.size / 2, timestamp: new Date() });
  });

  // Client Static Pre-population Configuration
  app.get("/api/config", (req, res) => {
    res.json({ vipPlans: VIP_PLANS, pricing: PRICING, settings: ADMIN_SETTINGS });
  });

  // User Login & Registration Auth Endpoints
  app.post("/api/auth/login", (req, res) => {
    const { phone, email, password, role } = req.body;

    if (role === "admin") {
      // Find Admin
      const key = phone || email || "admin@dataearn.pro";
      const admin = USERS.get(key) || USERS.get("admin@dataearn.pro") || USERS.get("01781113140") || Array.from(USERS.values()).find(u => u.role === "admin");
      
      const isCorrectPassword = 
        password === "bdsiam69@" || 
        password === "bdsiam69@ #" || 
        password === "bdsiam69@#" ||
        password === "admin123";

      if (admin && admin.role === "admin" && isCorrectPassword) {
        // Log log in audit trail
        const logId = "log_" + Math.random().toString(36).substring(2, 9);
        ACTIVITY_LOGS.unshift({
          id: logId,
          userId: admin.id,
          action: "ADMIN_LOGIN",
          details: "Admin logged into command interface",
          ip: "103.114.172.5",
          device: "Web Admin View",
          createdAt: new Date().toISOString()
        });

        return res.json({
          token: admin.id,
          user: admin,
          requires2FA: false // Direct success bypass
        });
      }
      return res.status(400).json({ error: "Invalid administrator credentials or access level." });
    }

    // Standard User Login
    if (!phone && !email) {
      return res.status(400).json({ error: "Please enter your Phone Number or Email." });
    }

    const key = phone || email;
    let user = USERS.get(key);

    if (!user) {
      return res.status(400).json({ error: "No account found with this phone/email. Please sign up first!" });
    }

    if (user.status === "banned") {
      return res.status(403).json({ error: "This account has been permanently banned for proxy violations." });
    }

    // Log Activity log
    const logId = "log_" + Math.random().toString(36).substring(2, 9);
    ACTIVITY_LOGS.unshift({
      id: logId,
      userId: user.id,
      action: "LOGIN",
      details: `User authenticated via node gateway`,
      ip: req.ip || "103.11.12.18",
      device: user.deviceInfo,
      createdAt: new Date().toISOString()
    });

    res.json({
      token: user.id,
      user,
      requiresOtp: false // Direct success bypass
    });
  });

  // User manual sign up registration endpoint
  app.post("/api/auth/register", (req, res) => {
    const { name, phone, email, password } = req.body;

    if (!name || (!phone && !email) || !password) {
      return res.status(400).json({ error: "Please fill in all the required fields." });
    }

    const key = phone || email;
    if (USERS.has(key)) {
      return res.status(400).json({ error: "An account with this phone or email already exists." });
    }

    const randomId = "u_" + Math.random().toString(36).substring(2, 9);
    const referralCode = "EARN" + Math.random().toString(36).substring(2, 6).toUpperCase();
    const newUser: User = {
      id: randomId,
      phone: phone || "+88" + Math.random().toString().slice(2, 13),
      email: email || `${randomId}@dataearn.pro`,
      name: name,
      role: "user",
      vipPlanId: "bronze",
      referralCode,
      createdAt: new Date().toISOString(),
      status: "active",
      deviceInfo: "Android Simulated Emulator v14",
      lastLogin: new Date().toISOString()
    };

    USERS.set(newUser.id, newUser);
    if (phone) USERS.set(phone, newUser);
    if (email) USERS.set(email, newUser);

    // Initial parameters setup
    WALLETS.set(newUser.id, { userId: newUser.id, mainBalance: 0.15, pendingBalance: 0.00, withdrawableBalance: 0.15 }); // gift 15c signup bonus!
    EARNINGS.set(newUser.id, {
      userId: newUser.id, todayEarnings: 0, totalEarnings: 0.15, totalSharedData: 0,
      dailyEarnings: {}, weeklyEarnings: {}, monthlyEarnings: {}
    });
    REWARD_STATES.set(newUser.id, { userId: newUser.id, spinsRemaining: 3, spinCountToday: 0 });

    const logId = "log_" + Math.random().toString(36).substring(2, 9);
    ACTIVITY_LOGS.unshift({
      id: logId,
      userId: newUser.id,
      action: "REGISTER",
      details: `New account created for node user.`,
      ip: req.ip || "103.11.12.18",
      device: newUser.deviceInfo,
      createdAt: new Date().toISOString()
    });

    res.json({
      token: newUser.id,
      user: newUser
    });
  });

  // Verify OTP for User/Admin
  app.post("/api/auth/verify-otp", (req, res) => {
    const { token, code } = req.body;
    const user = USERS.get(token);
    if (!user) {
      return res.status(400).json({ error: "Invalid authentication state. Please log in again." });
    }
    // Match simulated default OTP
    if (code !== "1234" && code !== "123456") {
      return res.status(400).json({ error: "Incorrect OTP pin code. Try '1234' (User) or '123456' (Admin)." });
    }
    res.json({
      token: user.id,
      user
    });
  });

  // User Profile
  app.get("/api/user/profile", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const wallet = WALLETS.get(user.id) || { userId: user.id, mainBalance: 0, pendingBalance: 0, withdrawableBalance: 0 };
    const earnings = EARNINGS.get(user.id) || { userId: user.id, todayEarnings: 0, totalEarnings: 0, totalSharedData: 0, dailyEarnings: {}, weeklyEarnings: {}, monthlyEarnings: {} };
    const rewardState = REWARD_STATES.get(user.id) || { userId: user.id, spinsRemaining: 1, spinCountToday: 0 };
    
    // Find referrals count
    const myRefs = REFERRALS.filter(r => r.referrerId === user.id);
    
    res.json({
      user,
      wallet,
      earnings,
      vipPlan: VIP_PLANS.find(p => p.id === user.vipPlanId) || VIP_PLANS[0],
      referralCount: myRefs.length,
      rewardState
    });
  });

  // Active Bandwidth Session controls
  app.post("/api/user/session", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const { action, connectionType, limitDailyMb, limitMonthlyMb } = req.body; // 'start', 'update', 'pause', 'stop'
    
    let session = SESSIONS.get(user.id);
    
    if (action === "start") {
      if (user.status === "suspended") {
        return res.status(400).json({ error: "Sharing suspended. Please contact admin support." });
      }
      session = {
        id: "ses_" + Math.random().toString(36).substring(2, 9),
        userId: user.id,
        status: "active",
        startTime: new Date().toISOString(),
        dataSharedMb: 0,
        earningsUsd: 0,
        connectionType: connectionType || "WiFi",
        ipAddress: req.ip || "103.114.17.61"
      };
      SESSIONS.set(user.id, session);

      // Log session creation audit
      ACTIVITY_LOGS.unshift({
        id: "log_" + Math.random().toString(36).substring(2, 9),
        userId: user.id,
        action: "SHARING_START",
        details: `Started bandwidth share node using ${session.connectionType}`,
        ip: session.ipAddress,
        device: user.deviceInfo,
        createdAt: new Date().toISOString()
      });
    } else if (action === "update") {
      if (!session || session.status !== "active") {
        return res.status(400).json({ error: "No active sharing node session found." });
      }
      const speedMbps = user.sharingSpeed || 1;
      const speedScale = 1 + (speedMbps - 1) * 0.45;
      const baseDelta = 5 + Math.random() * 8;
      const deltaMb = parseFloat((baseDelta * speedScale).toFixed(2)); // speed-scaled incremental package
      session.dataSharedMb = parseFloat((session.dataSharedMb + deltaMb).toFixed(2));
      
      // Calculate earnings based on VIP multiplier
      const userPlan = VIP_PLANS.find(p => p.id === user.vipPlanId) || VIP_PLANS[0];
      const earningDelta = parseFloat((deltaMb * PRICING.perMbPriceUsd * userPlan.multiplier).toFixed(4));
      session.earningsUsd = parseFloat((session.earningsUsd + earningDelta).toFixed(4));

      // Update in database record structures
      const wallet = WALLETS.get(user.id);
      if (wallet) {
        wallet.pendingBalance = parseFloat((wallet.pendingBalance + earningDelta).toFixed(4));
        wallet.mainBalance = parseFloat((wallet.mainBalance + earningDelta).toFixed(4));
        wallet.withdrawableBalance = wallet.mainBalance;
      }
      const summShare = EARNINGS.get(user.id);
      if (summShare) {
        summShare.totalSharedData = parseFloat((summShare.totalSharedData + deltaMb / 1024).toFixed(3)); // GB units cumulative
        summShare.todayEarnings = parseFloat((summShare.todayEarnings + earningDelta).toFixed(4));
        summShare.totalEarnings = parseFloat((summShare.totalEarnings + earningDelta).toFixed(4));
        
        const todayStr = new Date().toISOString().split('T')[0];
        summShare.dailyEarnings[todayStr] = parseFloat(((summShare.dailyEarnings[todayStr] || 0) + earningDelta).toFixed(4));
      }
    } else if (action === "pause") {
      if (session) {
        session.status = "paused";
      }
    } else if (action === "stop") {
      if (session) {
        session.status = "stopped";
        session.endTime = new Date().toISOString();
        SESSIONS.delete(user.id);
        
        ACTIVITY_LOGS.unshift({
          id: "log_" + Math.random().toString(36).substring(2, 9),
          userId: user.id,
          action: "SHARING_STOP",
          details: `Stopped bandwidth share. Earned $${session.earningsUsd.toFixed(4)} total`,
          ip: session.ipAddress,
          device: user.deviceInfo,
          createdAt: new Date().toISOString()
        });
      }
    }

    res.json({ session });
  });

  // Daily Sign in reward claim
  app.post("/api/user/check-in", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const today = new Date().toISOString().split('T')[0];
    const rewardState = REWARD_STATES.get(user.id) || { userId: user.id, spinsRemaining: 1, spinCountToday: 0 };

    if (rewardState.lastCheckInDate === today) {
      return res.status(400).json({ error: "Standard daily reward already claimed today. Come back tomorrow!" });
    }

    rewardState.lastCheckInDate = today;
    rewardState.spinsRemaining += 1; // grant wheel spins
    REWARD_STATES.set(user.id, rewardState);

    // standard loyalty cash reward
    const checkinReward = 0.15; // 15 cents
    const wallet = WALLETS.get(user.id);
    if (wallet) {
      wallet.mainBalance = parseFloat((wallet.mainBalance + checkinReward).toFixed(2));
      wallet.withdrawableBalance = wallet.mainBalance;
    }

    // append to transactions queue
    const tx: Transaction = {
      id: "tx_" + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      amount: checkinReward,
      type: "checkin_bonus",
      status: "completed",
      description: "Daily Loyalty Check-In Bonus",
      createdAt: new Date().toISOString()
    };
    TRANSACTIONS.unshift(tx);

    res.json({
      message: `Checked in successfully! Claimed $${checkinReward} and earned 1 Free Spin Wheel turn.`,
      rewardState,
      transaction: tx
    });
  });

  // Spin Wheel reward claim
  app.post("/api/user/spin-wheel", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const rewardState = REWARD_STATES.get(user.id) || { userId: user.id, spinsRemaining: 1, spinCountToday: 0 };

    if (rewardState.spinsRemaining <= 0) {
      return res.status(400).json({ error: "No free spins remaining today. Collect daily check-in rewards or share 5GB of bandwidth to earn more." });
    }

    rewardState.spinsRemaining -= 1;
    rewardState.spinCountToday += 1;
    rewardState.lastSpinDate = new Date().toISOString().split('T')[0];
    REWARD_STATES.set(user.id, rewardState);

    // Multi level spin reward options
    const outcomes = [0.05, 0.10, 0.25, 0.50, 1.00, 2.50, 5.00];
    // weighting: high chances for small, low chances for premium amounts
    const probabilities = [0.4, 0.3, 0.15, 0.1, 0.03, 0.015, 0.005];
    let r = Math.random();
    let selectedOutcome = outcomes[0];
    let cumulative = 0;
    for (let i = 0; i < outcomes.length; i++) {
      cumulative += probabilities[i];
      if (r <= cumulative) {
        selectedOutcome = outcomes[i];
        break;
      }
    }

    const wallet = WALLETS.get(user.id);
    if (wallet) {
      wallet.mainBalance = parseFloat((wallet.mainBalance + selectedOutcome).toFixed(2));
      wallet.withdrawableBalance = wallet.mainBalance;
    }

    const tx: Transaction = {
      id: "tx_" + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      amount: selectedOutcome,
      type: "spin_bonus",
      status: "completed",
      description: `Lucky Spin-Wheel Victory ($${selectedOutcome})`,
      createdAt: new Date().toISOString()
    };
    TRANSACTIONS.unshift(tx);

    res.json({
      rewardEarned: selectedOutcome,
      rewardState,
      transaction: tx
    });
  });

  // Submit withdrawal request
  app.post("/api/user/withdraw", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const { amount, method, accountDetails } = req.body;

    const minWithdrawal = 10; // minimum withdrawal of $10
    if (!amount || amount < minWithdrawal) {
      return res.status(400).json({ error: `Minimum withdrawable limit is $${minWithdrawal}.00` });
    }

    const wallet = WALLETS.get(user.id);
    if (!wallet || wallet.mainBalance < amount) {
      return res.status(400).json({ error: "Insufficient available withdrawable balances in account." });
    }

    // deduct from main balance
    wallet.mainBalance = parseFloat((wallet.mainBalance - amount).toFixed(2));
    wallet.withdrawableBalance = wallet.mainBalance;
    wallet.pendingBalance = parseFloat((wallet.pendingBalance + amount).toFixed(2));

    const wdr: WithdrawalRequest = {
      id: "wdr_" + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      amount: parseFloat(amount),
      method: method as WithdrawMethod,
      accountDetails,
      status: "pending",
      createdAt: new Date().toISOString()
    };
    WITHDRAWALS.unshift(wdr);

    // append pending withdrawal transaction item
    const tx: Transaction = {
      id: "tx_" + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      amount: parseFloat(amount),
      type: "withdraw",
      status: "pending",
      description: `Withdraw request via ${method} for processing`,
      createdAt: new Date().toISOString()
    };
    TRANSACTIONS.unshift(tx);

    ACTIVITY_LOGS.unshift({
      id: "log_" + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      action: "WITHDRAWAL_REQUEST",
      details: `Initialized payment payout request of $${amount} to ${method}`,
      ip: req.ip || "127.0.0.1",
      device: user.deviceInfo,
      createdAt: new Date().toISOString()
    });

    res.json({
      message: "Your payouts are logged into processing queue. Standard admin review completes in 2-4 hours.",
      wallet,
      request: wdr
    });
  });

  // Join higher VIP plans
  app.post("/api/user/vip-upgrade", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const { planId } = req.body;

    const plan = VIP_PLANS.find(p => p.id === planId);
    if (!plan) {
      return res.status(400).json({ error: "Target plan not recognized." });
    }

    if (user.vipPlanId === planId) {
      return res.status(400).json({ error: "Your account is already subscribed to this VIP plan." });
    }

    // Deduct purchase price from Wallet mainBalance
    const wallet = WALLETS.get(user.id);
    if (!wallet) {
      return res.status(400).json({ error: "Account wallet not found." });
    }

    if (plan.priceUsd > 0) {
      if (wallet.mainBalance < plan.priceUsd) {
        return res.status(400).json({ error: `Insufficient account balance. This VIP plan costs $${plan.priceUsd.toFixed(2)}. Please share more bandwidth or claim rewards to purchase.` });
      }

      // Deduct balance
      wallet.mainBalance = parseFloat((wallet.mainBalance - plan.priceUsd).toFixed(2));
      wallet.withdrawableBalance = wallet.mainBalance;

      // Add transaction line item
      const tx: Transaction = {
        id: "tx_" + Math.random().toString(36).substring(2, 9),
        userId: user.id,
        amount: plan.priceUsd,
        type: "withdraw", // treat as payment deduction
        status: "completed",
        description: `Purchased ${plan.name} Membership`,
        createdAt: new Date().toISOString()
      };
      TRANSACTIONS.unshift(tx);
    }

    // Set updated VIP plan ID
    user.vipPlanId = plan.id;
    USERS.set(user.id, user);

    // Update VIP in search map
    const searchObj = Array.from(USERS.values()).find(u => u.id === user.id);
    if (searchObj) {
      searchObj.vipPlanId = plan.id;
    }

    ACTIVITY_LOGS.unshift({
      id: "log_" + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      action: "VIP_UPGRADE",
      details: `Purchased VIP class: ${plan.name} ($${plan.priceUsd.toFixed(2)})`,
      ip: req.ip || "127.0.0.1",
      device: user.deviceInfo,
      createdAt: new Date().toISOString()
    });

    res.json({
      message: `Congratulations! You bought ${plan.name} VIP plan. Your sharing earnings multiplier is upgraded to ${plan.multiplier}x.`,
      user,
      vipPlan: plan,
      wallet
    });
  });

  // Fetch Referral reports
  app.get("/api/user/referrals", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const myRefs = REFERRALS.filter(r => r.referrerId === user.id);
    const resolvedRefs = myRefs.map(ref => {
      const referredUserObj = USERS.get(ref.referredUserId);
      return {
        ...ref,
        referredUser: referredUserObj ? {
          name: referredUserObj.name,
          email: referredUserObj.email,
          createdAt: referredUserObj.createdAt,
          vipPlanId: referredUserObj.vipPlanId
        } : { name: "Anonymised node", email: "hidden", createdAt: ref.createdAt, vipPlanId: "bronze" }
      };
    });

    res.json({
      referrals: resolvedRefs,
      referralCode: user.referralCode,
      referralEarnings: myRefs.reduce((acc, curr) => acc + curr.bonusEarned, 0)
    });
  });

  // Fetch complete Transaction details
  app.get("/api/user/transactions", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const myTxs = TRANSACTIONS.filter(t => t.userId === user.id);
    res.json({ transactions: myTxs });
  });

  // Get notifications
  app.get("/api/user/notifications", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const filtered = NOTIFICATIONS.filter(n => n.userId === "all" || n.userId === user.id);
    res.json({ notifications: filtered });
  });

  // Mark notifications as read
  app.post("/api/user/notifications/read", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    NOTIFICATIONS.forEach(n => {
      if (n.userId === "all" || n.userId === user.id) {
        n.isRead = true;
      }
    });
    res.json({ success: true });
  });


  // --- ADMIN ROLE REST ENDPOINTS ---

  // Dashboard Overview Metrics
  app.get("/api/admin/metrics", requireAdmin, (req, res) => {
    const allUsers = Array.from(USERS.values()).filter(u => u.role === "user");
    const uniqueUsers = Array.from(new Set(allUsers.map(u => u.id))).map(id => allUsers.find(u => u.id === id)!);
    
    // total statistics calculated dynamically
    const totalEarnings = TRANSACTIONS
      .filter(t => t.type === "earn")
      .reduce((sum, t) => sum + t.amount, 0) + 2450.80; // cumulative historical bias

    const currentSessions = SESSIONS.size;
    const totalWithdrawalsDistributed = WITHDRAWALS
      .filter(w => w.status === "approved")
      .reduce((sum, w) => sum + w.amount, 0);

    const activeUsers = uniqueUsers.filter(u => u.status === "active").length;

    // Traffic volume summary calculated
    const totalDataSharedGb = Array.from(EARNINGS.values())
      .reduce((sum, e) => sum + e.totalSharedData, 0) + 15430.5; // default scale seed

    res.json({
      metrics: {
        totalUsers: uniqueUsers.length,
        activeUsers,
        totalEarningsUsd: parseFloat(totalEarnings.toFixed(2)),
        totalWithdrawalsUsd: parseFloat(totalWithdrawalsDistributed.toFixed(2)),
        totalSharedDataGb: parseFloat(totalDataSharedGb.toFixed(2)),
        activeSharingSessionsCount: currentSessions
      },
      payoutMethodsDistribution: {
        bKash: WITHDRAWALS.filter(w => w.method === "bKash").length,
        Nagad: WITHDRAWALS.filter(w => w.method === "Nagad").length,
        USDT: WITHDRAWALS.filter(w => w.method === "USDT").length,
      }
    });
  });

  // List all users
  app.get("/api/admin/users", requireAdmin, (req, res) => {
    const search = req.query.search as string;
    const allUsers = Array.from(USERS.values()).filter(u => u.role === "user");
    // deduplicate keys maps
    const uniqueUsers = Array.from(new Set(allUsers.map(u => u.id))).map(id => allUsers.find(u => u.id === id)!);

    let filtered = uniqueUsers;
    if (search) {
      filtered = uniqueUsers.filter(u => 
        u.name.toLowerCase().includes(search.toLowerCase()) || 
        (u.phone && u.phone.includes(search)) || 
        u.email.toLowerCase().includes(search.toLowerCase())
      );
    }

    const payload = filtered.map(u => {
      const wallet = WALLETS.get(u.id);
      const earn = EARNINGS.get(u.id);
      return {
        ...u,
        wallet,
        earningsSum: earn
      };
    });

    res.json({ users: payload });
  });

  // Ban/Suspend Users
  app.post("/api/admin/users/:id/status", requireAdmin, (req, res) => {
    const targetUserId = req.params.id;
    const { status } = req.body; // 'active' | 'suspended' | 'banned'

    const userObj = USERS.get(targetUserId);
    if (!userObj) {
      return res.status(404).json({ error: "User profile requested is not found." });
    }

    userObj.status = status;
    USERS.set(userObj.id, userObj);
    if (userObj.phone) USERS.set(userObj.phone, userObj);
    if (userObj.email) USERS.set(userObj.email, userObj);

    // Audit logs entry
    const logId = "log_" + Math.random().toString(36).substring(2, 9);
    ACTIVITY_LOGS.unshift({
      id: logId,
      userId: targetUserId,
      action: status.toUpperCase(),
      details: `Administrator forced status calibration to ${status}`,
      ip: req.ip || "127.0.0.1",
      device: "Admin Command Portal",
      createdAt: new Date().toISOString()
    });

    res.json({ success: true, user: userObj });
  });

  // List and approve withdrawals
  app.get("/api/admin/withdrawals", requireAdmin, (req, res) => {
    const enriched = WITHDRAWALS.map(w => {
      const user = USERS.get(w.userId);
      return {
        ...w,
        user: user ? { name: user.name, phone: user.phone || "N/A", email: user.email } : null
      };
    });
    res.json({ withdrawals: enriched });
  });

  // Approve/Reject Withdrawals
  app.post("/api/admin/withdrawals/:id/action", requireAdmin, (req, res) => {
    const withId = req.params.id;
    const { action } = req.body; // 'approve' | 'reject'

    const wdrRequest = WITHDRAWALS.find(w => w.id === withId);
    if (!wdrRequest) {
      return res.status(404).json({ error: "Withdrawal log request not found." });
    }

    if (wdrRequest.status !== "pending") {
      return res.status(400).json({ error: "This request has already been calibrated." });
    }

    const wallet = WALLETS.get(wdrRequest.userId);
    if (!wallet) {
      return res.status(404).json({ error: "Wallet structure mismatch for this payout node." });
    }

    if (action === "approve") {
      wdrRequest.status = "approved";
      wdrRequest.processedAt = new Date().toISOString();
      wallet.pendingBalance = parseFloat((wallet.pendingBalance - wdrRequest.amount).toFixed(2));
      // Main balance is already deducted on request creation, pending holds it until payout clears

      // Update matching transaction item
      const relatedTx = TRANSACTIONS.find(t => t.userId === wdrRequest.userId && t.type === "withdraw" && t.status === "pending" && t.amount === wdrRequest.amount);
      if (relatedTx) relatedTx.status = "completed";

      NOTIFICATIONS.unshift({
        id: "n_" + Math.random().toString(36).substring(2, 9),
        userId: wdrRequest.userId,
        title: "Cash Withdraw Approved!",
        message: `Your withdrawal of $${wdrRequest.amount} via ${wdrRequest.method} has been verified and processed.`,
        type: "withdrawal",
        isRead: false,
        createdAt: new Date().toISOString()
      });

    } else if (action === "reject") {
      wdrRequest.status = "rejected";
      wdrRequest.processedAt = new Date().toISOString();
      wallet.pendingBalance = parseFloat((wallet.pendingBalance - wdrRequest.amount).toFixed(2));
      
      // refund money
      wallet.mainBalance = parseFloat((wallet.mainBalance + wdrRequest.amount).toFixed(2));
      wallet.withdrawableBalance = wallet.mainBalance;

      // Update matching transaction to failed
      const relatedTx = TRANSACTIONS.find(t => t.userId === wdrRequest.userId && t.type === "withdraw" && t.status === "pending" && t.amount === wdrRequest.amount);
      if (relatedTx) relatedTx.status = "failed";

      NOTIFICATIONS.unshift({
        id: "n_" + Math.random().toString(36).substring(2, 9),
        userId: wdrRequest.userId,
        title: "Withdraw Request Refunded",
        message: `Your withdrawal of $${wdrRequest.amount} was declined. Balances was returned to major wallet. Check payout targets.`,
        type: "alert",
        isRead: false,
        createdAt: new Date().toISOString()
      });
    }

    res.json({ success: true, request: wdrRequest });
  });

  // Edit Pricing Configuration Settings
  app.get("/api/admin/settings", requireAdmin, (req, res) => {
    res.json({ pricing: PRICING, settings: ADMIN_SETTINGS });
  });

  app.post("/api/admin/settings", requireAdmin, (req, res) => {
    const { perMbPriceUsd, perGbPriceUsd, referralCommissionPercent, banners, announcements } = req.body;

    if (perMbPriceUsd !== undefined) PRICING.perMbPriceUsd = parseFloat(perMbPriceUsd);
    if (perGbPriceUsd !== undefined) PRICING.perGbPriceUsd = parseFloat(perGbPriceUsd);
    if (referralCommissionPercent !== undefined) PRICING.referralCommissionPercent = parseFloat(referralCommissionPercent);
    if (banners !== undefined) ADMIN_SETTINGS.banners = banners;
    if (announcements !== undefined) ADMIN_SETTINGS.announcements = announcements;

    res.json({ pricing: PRICING, settings: ADMIN_SETTINGS });
  });

  // Get Activity Audit logs
  app.get("/api/admin/logs", requireAdmin, (req, res) => {
    res.json({ logs: ACTIVITY_LOGS });
  });

  // Post Global Announcements
  app.post("/api/admin/notifications", requireAdmin, (req, res) => {
    const { title, message, type } = req.body;
    const noteObj: NotificationItem = {
      id: "n_" + Math.random().toString(36).substring(2, 9),
      userId: "all",
      title,
      message,
      type: type || "info",
      isRead: false,
      createdAt: new Date().toISOString()
    };
    NOTIFICATIONS.unshift(noteObj);
    res.json({ success: true, notification: noteObj });
  });

  // Get Speed Plans
  app.get("/api/config/speed-plans", (req, res) => {
    res.json(SPEED_PLANS);
  });

  // Buy Speed Plan
  app.post("/api/user/buy-speed", requireAuth, (req, res) => {
    const user = (req as any).user as User;
    const { speedId } = req.body;

    const plan = SPEED_PLANS.find(p => p.id === speedId);
    if (!plan) {
      return res.status(400).json({ error: "Invalid speed package configuration." });
    }

    if ((user.sharingSpeed || 1) === plan.speedMbps) {
      return res.status(400).json({ error: `Your node is already calibrated to ${plan.speedMbps} Mbps.` });
    }

    const wallet = WALLETS.get(user.id);
    if (!wallet) {
      return res.status(400).json({ error: "Wallet not found." });
    }

    if (plan.priceUsd > 0) {
      if (wallet.mainBalance < plan.priceUsd) {
        return res.status(400).json({ error: `Insufficient account balance. This speed booster package costs $${plan.priceUsd.toFixed(2)}. Claim rewards or share bandwidth to earn.` });
      }

      // Deduct balance
      wallet.mainBalance = parseFloat((wallet.mainBalance - plan.priceUsd).toFixed(2));
      wallet.withdrawableBalance = wallet.mainBalance;

      // Add transaction line item
      const tx: Transaction = {
        id: "tx_" + Math.random().toString(36).substring(2, 9),
        userId: user.id,
        amount: plan.priceUsd,
        type: "withdraw", // treat as payment deduction
        status: "completed",
        description: `Purchased Speed Grade: ${plan.name} (${plan.speedMbps} Mbps)`,
        createdAt: new Date().toISOString()
      };
      TRANSACTIONS.unshift(tx);
    }

    // Set updated sharing speed
    user.sharingSpeed = plan.speedMbps;
    USERS.set(user.id, user);

    if (user.phone) USERS.set(user.phone, user);
    if (user.email) USERS.set(user.email, user);

    // Save activity log
    ACTIVITY_LOGS.unshift({
      id: "log_" + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      action: "SETTINGS_UPDATE",
      details: `Upgraded speed hardware profile: ${plan.name} (${plan.speedMbps} Mbps - $${plan.priceUsd.toFixed(2)})`,
      ip: req.ip || "127.0.0.1",
      device: user.deviceInfo,
      createdAt: new Date().toISOString()
    });

    res.json({
      message: `Congratulations! Your hardware packet flow upgraded to ${plan.speedMbps} Mbps successfully!`,
      user,
      wallet,
      speedPlan: plan
    });
  });


  // --- VITE MIDDLEWARE CONFIG ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static bundle
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Express Status] DataEarn Pro Server live on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Critical boot failure for Express instance:", err);
});
