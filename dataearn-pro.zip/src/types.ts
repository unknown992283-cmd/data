/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// User roles in the system
export type Role = 'user' | 'admin';

export interface User {
  id: string; // Phone number or unique id
  phone?: string;
  email: string;
  name: string;
  role: Role;
  vipPlanId: string;                         // e.g. 'bronze' | 'silver' | 'gold' | 'diamond'
  referredBy?: string;                       // Referral code of the registerer
  referralCode: string;                      // Self referral code
  createdAt: string;
  status: 'active' | 'suspended' | 'banned';
  deviceInfo: string;
  lastLogin: string;
  sharingSpeed?: number;                     // in Mbps (defaults to 1 Mbps)
}

export interface SpeedPlan {
  id: string;
  name: string;
  speedMbps: number;
  priceUsd: number;
  color: string;
  description: string;
}

export interface Wallet {
  userId: string;
  mainBalance: number;                       // in USD or BDT depending on preference (we can show both!)
  pendingBalance: number;
  withdrawableBalance: number;
}

export interface EarningSummary {
  userId: string;
  todayEarnings: number;
  totalEarnings: number;
  totalSharedData: number;                   // in MB
  dailyEarnings: { [date: string]: number }; // date to amount map
  weeklyEarnings: { [week: string]: number };
  monthlyEarnings: { [month: string]: number };
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: 'earn' | 'withdraw' | 'referral_bonus' | 'checkin_bonus' | 'spin_bonus';
  status: 'completed' | 'pending' | 'failed';
  description: string;
  createdAt: string;
}

export type WithdrawMethod = 'bKash' | 'Nagad' | 'Rocket' | 'Binance Pay' | 'USDT' | 'Bank Transfer';

export interface WithdrawalRequest {
  id: string;
  userId: string;
  amount: number;
  method: WithdrawMethod;
  accountDetails: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  processedAt?: string;
}

export interface Referral {
  id: string;
  referrerId: string;
  referredUserId: string;
  bonusEarned: number;
  status: 'active' | 'pending';
  createdAt: string;
}

export interface VIPPlan {
  id: string;
  name: string; // Bronze, Silver, Gold, Diamond
  minDataShared: number; // in GB to unlock or requirements
  multiplier: number; // e.g. 1.0, 1.2, 1.5, 2.0
  perGbRate: number; // base rate * multiplier
  iconName: string;
  color: string;
  priceUsd: number; // purchase price of the plan
}

export interface RewardState {
  userId: string;
  lastCheckInDate?: string; // YYYY-MM-DD
  spinsRemaining: number;
  spinCountToday: number;
  lastSpinDate?: string;
}

export interface NetworkSession {
  id: string;
  userId: string;
  status: 'active' | 'paused' | 'stopped';
  startTime: string;
  endTime?: string;
  dataSharedMb: number;
  earningsUsd: number;
  connectionType: 'WiFi' | 'Cellular';
  ipAddress: string;
}

export interface NotificationItem {
  id: string;
  userId: string | 'all'; // 'all' for dynamic global announcements
  title: string;
  message: string;
  type: 'info' | 'earning' | 'withdrawal' | 'alert';
  isRead: boolean;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  details: string;
  ip: string;
  device: string;
  createdAt: string;
}

// Pricing Settings Managed by Admin
export interface PricingConfig {
  perMbPriceUsd: number; // e.g. 0.0001
  perGbPriceUsd: number; // e.g. 0.10
  referralCommissionPercent: number; // e.g. 10 for 10%
  baseWeeklyReward: number; // standard reward values
}

// Banner Settings Managed by Admin
export interface AdminSettings {
  banners: { id: string; url: string; title: string; active: boolean }[];
  announcements: { id: string; content: string; active: boolean }[];
  fraudThresholdGb: number; // automatic warning if excessive sharing
}
