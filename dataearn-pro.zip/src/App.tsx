/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Home, TrendingUp, Wallet, Share2, User, Users, DollarSign,
  Activity, Settings, Bell, Lock, RefreshCw, Play, Pause,
  Square, Plus, Search, Moon, Sun, Sliders, CheckCircle2,
  AlertTriangle, ChevronRight, Award, ShieldCheck,
  Flame, Gem, Copy, Check, Info, Clock, Terminal, Laptop, Phone,
  Wifi, Sparkles, Coins
} from 'lucide-react';
import { 
  Role, User as UserType, Wallet as WalletType, EarningSummary, 
  Transaction, WithdrawalRequest, Referral, VIPPlan, RewardState, 
  NetworkSession, NotificationItem, ActivityLog, PricingConfig, 
  AdminSettings, WithdrawMethod, SpeedPlan
} from './types';

export default function App() {
  // Authentication & Auth state
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [user, setUser] = useState<UserType | null>(null);
  const [role, setRole] = useState<Role>('user');
  
  // Login fields
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('1234');
  const [authStep, setAuthStep] = useState<'login' | 'otp' | '2fa'>('login');
  const [otpCode, setOtpCode] = useState('');
  const [authError, setAuthError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Registration fields
  const [isRegistering, setIsRegistering] = useState(false);
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');

  // User States
  const [wallet, setWallet] = useState<WalletType | null>(null);
  const [earnings, setEarnings] = useState<EarningSummary | null>(null);
  const [rewardState, setRewardState] = useState<RewardState | null>(null);
  const [vipPlan, setVipPlan] = useState<VIPPlan | null>(null);
  const [referrals, setReferrals] = useState<{ referrals: Referral[]; referralEarnings: number } | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [activeSession, setActiveSession] = useState<NetworkSession | null>(null);

  // Form states / Dialog switches
  const [vipMessage, setVipMessage] = useState('');
  const [vipError, setVipError] = useState('');
  const [speedPlans, setSpeedPlans] = useState<SpeedPlan[]>([]);
  const [speedMessage, setSpeedMessage] = useState('');
  const [speedError, setSpeedError] = useState('');
  const [userActiveTab, setUserActiveTab] = useState<'home' | 'earnings' | 'wallet' | 'referral' | 'profile'>('home');
  const [userSubPage, setUserSubPage] = useState<null | 'sharing_ctrl' | 'vip_club' | 'speed_booster' | 'reward_hub' | 'withdraw_portal' | 'transactions_list'>(null);
  const [pullToRefreshing, setPullToRefreshing] = useState(false);
  const [copiedText, setCopiedText] = useState(false);

  // Interactive reward wheel states
  const [spinning, setSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState<number | null>(null);
  const [rewardClaimMessage, setRewardClaimMessage] = useState('');

  // Active Sharing controller setups
  const [connectionType, setConnectionType] = useState<'WiFi' | 'Cellular'>('WiFi');
  const [dailyLimitMb, setDailyLimitMb] = useState(1024);
  const [monthlyLimitMb, setMonthlyLimitMb] = useState(10240);
  const [sharingTrafficLogs, setSharingTrafficLogs] = useState<string[]>([]);

  // Withdrawal form
  const [withdrawMethod, setWithdrawMethod] = useState<WithdrawMethod>('bKash');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAccount, setWithdrawAccount] = useState('');
  const [withdrawMessage, setWithdrawMessage] = useState('');
  const [withdrawErr, setWithdrawErr] = useState('');

  // Admin States
  const [adminActiveTab, setAdminActiveTab] = useState<'dashboard' | 'users' | 'withdrawals' | 'analytics' | 'settings'>('dashboard');
  const [adminMetrics, setAdminMetrics] = useState<any>(null);
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [adminWithdrawals, setAdminWithdrawals] = useState<any[]>([]);
  const [adminLogs, setAdminLogs] = useState<ActivityLog[]>([]);
  const [adminSearchQuery, setAdminSearchQuery] = useState('');
  
  // Admin settings inputs
  const [configPricing, setConfigPricing] = useState<PricingConfig>({ perMbPriceUsd: 0.00015, perGbPriceUsd: 0.15, referralCommissionPercent: 12, baseWeeklyReward: 0.50 });
  const [adminBanners, setAdminBanners] = useState<any[]>([]);
  const [adminAnnouncements, setAdminAnnouncements] = useState<any[]>([]);
  const [announcementInput, setAnnouncementInput] = useState('');
  const [bannerInputUrl, setBannerInputUrl] = useState('');
  const [bannerInputTitle, setBannerInputTitle] = useState('');

  // UI Theme (Light/Dark physical phone frame override state)
  const [darkMode, setDarkMode] = useState(true);

  // Interval reference for live sharing tracking upload
  const sessionTimerRef = useRef<any>(null);

  // 1. Core Config Init On Boot
  useEffect(() => {
    fetchConfig();
    if (token) {
      if (token.startsWith('admin')) {
        setRole('admin');
        fetchAdminData();
      } else {
        setRole('user');
        fetchUserData();
      }
    }
  }, [token]);

  // Handle active session mock tracker interval
  useEffect(() => {
    if (activeSession && activeSession.status === 'active') {
      sessionTimerRef.current = setInterval(() => {
        postSessionUpdate();
      }, 4000); // execute mock state transfer every 4 seconds
    } else {
      if (sessionTimerRef.current) {
        clearInterval(sessionTimerRef.current);
        sessionTimerRef.current = null;
      }
    }
    return () => {
      if (sessionTimerRef.current) clearInterval(sessionTimerRef.current);
    };
  }, [activeSession]);

  const fetchSpeedPlans = async () => {
    try {
      const res = await fetch('/api/config/speed-plans');
      if (res.ok) {
        const data = await res.json();
        setSpeedPlans(data);
      }
    } catch (e) {}
  };

  const fetchConfig = async () => {
    try {
      const res = await fetch('/api/config');
      const data = await res.json();
      if (data) {
        setConfigPricing(data.pricing);
        setAdminBanners(data.settings.banners || []);
        setAdminAnnouncements(data.settings.announcements || []);
      }
      fetchSpeedPlans();
    } catch (e) {
      console.error(e);
    }
  };

  const fetchUserData = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/user/profile', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setWallet(data.wallet);
        setEarnings(data.earnings);
        setRewardState(data.rewardState);
        setVipPlan(data.vipPlan);
        
        // fetch other segments
        fetchUserReferrals();
        fetchUserTransactions();
        fetchUserNotifications();
      } else {
        // Clear token if invalid
        handleLogout();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchUserReferrals = async () => {
    try {
      const res = await fetch('/api/user/referrals', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setReferrals(data);
    } catch (e) {}
  };

  const fetchUserTransactions = async () => {
    try {
      const res = await fetch('/api/user/transactions', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setTransactions(data.transactions || []);
    } catch (e) {}
  };

  const fetchUserNotifications = async () => {
    try {
      const res = await fetch('/api/user/notifications', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setNotifications(data.notifications || []);
    } catch (e) {}
  };

  const fetchAdminData = async () => {
    if (!token) return;
    try {
      // 1. Fetch Metrics
      const resMet = await fetch('/api/admin/metrics', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (resMet.ok) {
        const metData = await resMet.json();
        setAdminMetrics(metData);
      } else {
        handleLogout();
        return;
      }

      // 2. Fetch Users List
      const resUsr = await fetch(`/api/admin/users?search=${encodeURIComponent(adminSearchQuery)}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const usrData = await resUsr.json();
      setAdminUsers(usrData.users || []);

      // 3. Fetch Withdraw List
      const resWith = await fetch('/api/admin/withdrawals', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const withData = await resWith.json();
      setAdminWithdrawals(withData.withdrawals || []);

      // 4. Fetch Logs
      const resLogs = await fetch('/api/admin/logs', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const logsData = await resLogs.json();
      setAdminLogs(logsData.logs || []);

      // 5. Fetch Settings
      const resSet = await fetch('/api/admin/settings', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const setData = await resSet.json();
      setConfigPricing(setData.pricing);
      setAdminBanners(setData.settings.banners || []);
      setAdminAnnouncements(setData.settings.announcements || []);

    } catch (e) {
      console.error(e);
    }
  };

  // Pull to refresh simulation
  const handlePullToRefresh = async () => {
    setPullToRefreshing(true);
    if (role === 'admin') {
      await fetchAdminData();
    } else {
      await fetchUserData();
    }
    setTimeout(() => {
      setPullToRefreshing(false);
    }, 800);
  };

  // Login click handlers
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsLoggingIn(true);
    try {
      const loginPayload = role === 'admin' 
        ? { email, phone, password, role: 'admin' }
        : { phone: phone || '+8801712345678', email, password, role: 'user' };

      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginPayload)
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('token', data.token);
        setToken(data.token);
        setUser(data.user);
        setAuthStep('login');
        
        // Redirect tabs correctly
        if (data.user.role === 'admin') {
          setRole('admin');
          setAdminActiveTab('dashboard');
        } else {
          setRole('user');
          setUserActiveTab('home');
          setUserSubPage(null);
        }
      } else {
        setAuthError(data.error || 'Login failed');
      }
    } catch (err: any) {
      setAuthError('Network error connecting to platform gateway.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Registration click submission handler
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!regName.trim()) {
      setAuthError('Please enter your full name.');
      return;
    }
    if (!regPhone.trim() && !regEmail.trim()) {
      setAuthError('Please enter either a phone number or email address.');
      return;
    }
    setIsLoggingIn(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          phone: regPhone,
          email: regEmail,
          password: regPassword
        })
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('token', data.token);
        setToken(data.token);
        setUser(data.user);
        setAuthStep('login');
        setIsRegistering(false);
        setRole('user');
        setUserActiveTab('home');
        setUserSubPage(null);
        // Clear registration input states
        setRegName('');
        setRegPhone('');
        setRegEmail('');
        setRegPassword('');
      } else {
        setAuthError(data.error || 'Registration failed');
      }
    } catch (err: any) {
      setAuthError('Connection failure during registration gateway handshake.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleVerifyOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsLoggingIn(true);
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: user?.id, code: otpCode })
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('token', data.token);
        setToken(data.token);
        setUser(data.user);
        setAuthStep('login');
        setOtpCode('');
        
        // Redirect tabs correctly
        if (data.user.role === 'admin') {
          setRole('admin');
          setAdminActiveTab('dashboard');
        } else {
          setRole('user');
          setUserActiveTab('home');
          setUserSubPage(null);
        }
      } else {
        setAuthError(data.error || 'Invalid OTP');
      }
    } catch (err) {
      setAuthError('Otp verification service error.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    setWallet(null);
    setEarnings(null);
    setActiveSession(null);
    setAuthStep('login');
    setUserSubPage(null);
  };

  // DATA SHARING ACTIONS WITH EXPRESS BACKEND
  const startSharingNode = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/user/session', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action: 'start', connectionType })
      });
      const data = await res.json();
      if (res.ok) {
        setActiveSession(data.session);
        addTrafficLog(`Established dynamic socket server route. Tunneled via IPv4 (${data.session.ipAddress})`);
        addTrafficLog(`Verifying background device parameters... Compatible payload detected!`);
        addTrafficLog(`Data stream is now ACTIVE. Upload speed calibrating...`);
      } else {
        alert(data.error);
      }
    } catch (e) {}
  };

  const pauseSharingNode = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/user/session', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action: 'pause' })
      });
      const data = await res.json();
      if (res.ok) {
        setActiveSession({ ...activeSession, status: 'paused' } as any);
        addTrafficLog(`Bandwidth streaming is suspended cleanly. Hold gateway active.`);
      }
    } catch (e) {}
  };

  const stopSharingNode = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/user/session', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action: 'stop' })
      });
      const data = await res.json();
      if (res.ok) {
        setActiveSession(null);
        addTrafficLog(`Session terminated. Released socket port variables.`);
        fetchUserData(); // update totals
      }
    } catch (e) {}
  };

  const postSessionUpdate = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/user/session', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action: 'update' })
      });
      const data = await res.json();
      if (res.ok && data.session) {
        setActiveSession(data.session);
        
        // update simple logs
        const transDelta = (5 + Math.random() * 8).toFixed(1);
        addTrafficLog(`Package Transfer: Successfully uploaded packet (${transDelta} MB chunks) -- Rate +$0.012`);
        // Refresh profile stats in background gently
        fetchUserData();
      }
    } catch (e) {}
  };

  const addTrafficLog = (msg: string) => {
    const time = new Date().toLocaleTimeString();
    setSharingTrafficLogs(prev => [`[${time}] ${msg}`, ...prev.slice(0, 15)]);
  };

  // CHECKIN CLAIM LOYALTY
  const claimCheckIn = async () => {
    try {
      const res = await fetch('/api/user/check-in', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setRewardClaimMessage(data.message);
        fetchUserData();
      } else {
        setRewardClaimMessage(data.error);
      }
    } catch (e) {}
  };

  // LUCKY SPIN WHEEL CONTROLLER
  const triggerSpinLuckyWheel = async () => {
    if (spinning) return;
    setSpinning(true);
    setRewardClaimMessage('');
    setSpinResult(null);

    // Simulated wheel rotate delay in frontend physical representation
    setTimeout(async () => {
      try {
        const res = await fetch('/api/user/spin-wheel', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        if (res.ok) {
          setSpinResult(data.rewardEarned);
          setRewardClaimMessage(`Jackpot Award! You gained a bonus of $${data.rewardEarned.toFixed(2)} credited straight to your Withdrawable main balance!`);
          fetchUserData();
        } else {
          setRewardClaimMessage(data.error);
        }
      } catch (e) {
        setRewardClaimMessage("Error syncing with backend spinning node.");
      } finally {
        setSpinning(false);
      }
    }, 2500);
  };

  // WITHDRAW SUBMISSIONS
  const handleSubmitWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawErr('');
    setWithdrawMessage('');
    if (!withdrawAmount || parseFloat(withdrawAmount) < 10) {
      setWithdrawErr("The minimum threshold required is $10.00 USD.");
      return;
    }
    if (!withdrawAccount) {
      setWithdrawErr("Standard pay credentials or physical receiver reference is required.");
      return;
    }

    try {
      const res = await fetch('/api/user/withdraw', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          amount: parseFloat(withdrawAmount),
          method: withdrawMethod,
          accountDetails: withdrawAccount
        })
      });
      const data = await res.json();
      if (res.ok) {
        setWithdrawMessage(data.message);
        setWithdrawAmount('');
        setWithdrawAccount('');
        fetchUserData();
      } else {
        setWithdrawErr(data.error || "Execution error on checkout platform.");
      }
    } catch (e) {
      setWithdrawErr("Server failure on withdrawal validation.");
    }
  };

  const handleVipUpgrade = async (planId: string) => {
    setVipMessage('');
    setVipError('');
    try {
      const res = await fetch('/api/user/vip-upgrade', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ planId })
      });
      const data = await res.json();
      if (res.ok) {
        setVipMessage(data.message);
        fetchUserData();
        // Clear message in 5 seconds
        setTimeout(() => setVipMessage(''), 5000);
      } else {
        setVipError(data.error);
      }
    } catch (e) {
      setVipError("Connection failure during VIP node upgrade setup.");
    }
  };

  const handleSpeedUpgrade = async (speedId: string) => {
    setSpeedMessage('');
    setSpeedError('');
    try {
      const res = await fetch('/api/user/buy-speed', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ speedId })
      });
      const data = await res.json();
      if (res.ok) {
        setSpeedMessage(data.message);
        fetchUserData();
        setTimeout(() => setSpeedMessage(''), 5000);
      } else {
        setSpeedError(data.error);
      }
    } catch (e) {
      setSpeedError("Connection failure during Speed Upgrade.");
    }
  };

  // ADMIN OPERATIONS
  const handleUserStatusChange = async (userId: string, targetStatus: string) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/status`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status: targetStatus })
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch (e) {}
  };

  const handleWithdrawalAction = async (witId: string, actionName: 'approve' | 'reject') => {
    try {
      const res = await fetch(`/api/admin/withdrawals/${witId}/action`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action: actionName })
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch (e) {}
  };

  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementInput) return;
    try {
      const res = await fetch('/api/admin/notifications', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          title: "System Update Announcement",
          message: announcementInput,
          type: "info"
        })
      });
      if (res.ok) {
        setAnnouncementInput('');
        fetchAdminData();
        alert("Broadcast announcement successfully published!");
      }
    } catch (e) {}
  };

  const handleSavePricingConfig = async () => {
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          perMbPriceUsd: configPricing.perMbPriceUsd,
          perGbPriceUsd: configPricing.perGbPriceUsd,
          referralCommissionPercent: configPricing.referralCommissionPercent
        })
      });
      if (res.ok) {
        alert("System base rates saved onto cloud successfully!");
        fetchAdminData();
      }
    } catch (e) {}
  };

  // Copy referral code link helper
  const handleCopyLink = (code: string) => {
    const fullUrl = `https://dataearn.pro/register?ref=${code}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Live total earnings counter ticking continuously to give passive earning feeling!
  const [liveCounterBias, setLiveCounterBias] = useState(0);
  useEffect(() => {
    let interval: any;
    if (activeSession && activeSession.status === 'active') {
      interval = setInterval(() => {
        setLiveCounterBias(p => p + 0.0002);
      }, 350);
    } else {
      setLiveCounterBias(0);
    }
    return () => clearInterval(interval);
  }, [activeSession]);

  const activeMainBalance = useMemo(() => {
    if (!wallet) return 0;
    return wallet.mainBalance + liveCounterBias;
  }, [wallet, liveCounterBias]);

  return (
    <div className={`min-h-screen py-10 px-4 transition-colors duration-300 font-sans flex items-center justify-center ${darkMode ? 'bg-[#0a0815] text-white' : 'bg-slate-100 text-slate-800'}`}>
      <div id="main_wrapper" className="w-full max-w-7xl flex justify-center items-center">
        
        {/* RIGHT COLUMN: 16:9 Android Emulator Mockup Viewport */}
        <div id="android_emulator_screen" className="flex justify-center w-full">
          
          {/* Physical Phone Frame Core */}
          <div className={`relative w-full max-w-[420px] h-[820px] rounded-[48px] border-[12px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden transition-all duration-300 flex flex-col ${
            darkMode 
              ? 'bg-[#070510] border-[#1e1a38] shadow-[#000]' 
              : 'bg-slate-55 border-slate-300 shadow-slate-400'
          }`}>
            
            {/* Phone Notch/Dynamic Island Speaker & Front Camera */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-full z-50 flex items-center justify-between px-3">
              <div className="w-1.5 h-1.5 bg-zinc-800 rounded-full" />
              <div id="notch_lens" className="w-[11px] h-[11px] bg-indigo-950 rounded-full border border-indigo-900 flex items-center justify-center">
                <div className="w-[3px] h-[3px] bg-blue-500 rounded-full" />
              </div>
              <div className="w-10 h-1 bg-zinc-800 rounded-full" />
            </div>

            {/* Simulated Android Status Bar */}
            <div className={`h-11 pt-3 px-6 flex items-center justify-between text-xs z-40 font-mono select-none ${
              userActiveTab === 'home' && !userSubPage && !token ? 'bg-transparent' : darkMode ? 'bg-[#0f0c1b]/85' : 'bg-slate-100/95'
            }`}>
              {/* Local system simulated time */}
              <div id="status_bar_time" className="font-semibold text-[11px]">
                {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
              {/* Phone hardware indicators */}
              <div id="status_bar_icons" className="flex items-center gap-1.5 text-[10px]">
                <Clock className="h-3 w-3 inline text-violet-400" />
                <span className="text-[9px] text-violet-400 uppercase font-bold mr-1">5G PRO</span>
                <Wifi className="h-3.5 w-3.5 inline text-emerald-400" />
                <div className="flex items-center gap-0.5 border border-current rounded px-0.5 h-3">
                  <div className="w-3.5 h-1.5 bg-current rounded-sm" />
                </div>
                <span className="text-[9px]">98%</span>
              </div>
            </div>

            {/* Inner App Canvas Shell (Includes Pull to refresh container context) */}
            <div id="phone_content_area" className={`flex-1 overflow-y-auto overflow-x-hidden relative flex flex-col ${
              darkMode ? 'bg-[#0e0c1e] text-slate-100' : 'bg-slate-50 text-slate-900'
            }`}>
              
              {/* Pull-to-refresh Indicator */}
              {pullToRefreshing && (
                <div className="bg-violet-600 text-white text-xs py-2 text-center flex items-center justify-center gap-2 animate-bounce z-50 shadow-md">
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  Synchronizing state nodes...
                </div>
              )}

              {/* ------------------------- STATE A: NOT LOGGED IN ------------------------- */}
              {!token ? (
                <div id="auth_view" className="flex-1 flex flex-col justify-between p-6">
                  
                  {/* Brand identity section */}
                  <div className="text-center mt-6">
                    <div className="w-20 h-20 bg-gradient-to-tr from-violet-600 to-purple-500 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-violet-500/20 mb-4 animate-pulse-slow">
                      <TrendingUp className="h-10 w-10 text-white" />
                    </div>
                    <h2 className="text-3xl font-black font-display tracking-tight bg-gradient-to-r from-violet-400 to-purple-300 bg-clip-text text-transparent">
                      DataEarn Pro
                    </h2>
                    <p className="text-xs text-slate-400 mt-1 uppercase font-bold tracking-widest">Global proxy distribution network</p>
                  </div>

                  {/* FORM INTERFACING */}
                  <div className="my-auto space-y-4">
                    
                    {/* Role selections trigger */}
                    <div className="grid grid-cols-2 bg-slate-800/60 p-1.5 rounded-xl border border-slate-700/50 mb-2">
                      <button
                        id="role_user_btn"
                        type="button"
                        onClick={() => { setRole('user'); setAuthError(''); setAuthStep('login'); }}
                        className={`py-2 text-xs font-bold rounded-lg transition-all ${
                          role === 'user' ? 'bg-violet-600 text-white shadow' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Client Panel
                      </button>
                      <button
                        id="role_admin_btn"
                        type="button"
                        onClick={() => { setRole('admin'); setAuthError(''); setAuthStep('login'); }}
                        className={`py-2 text-xs font-bold rounded-lg transition-all ${
                          role === 'admin' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Admin Command
                      </button>
                    </div>

                    {role === 'user' && (
                      <div className="flex justify-center gap-6 text-xs font-bold border-b border-slate-800 pb-3 mb-2">
                        <button
                          id="tab_login"
                          type="button"
                          onClick={() => { setIsRegistering(false); setAuthError(''); }}
                          className={`pb-1.5 px-3 transition-all ${!isRegistering ? 'text-violet-400 border-b-2 border-violet-500' : 'text-slate-400 hover:text-white'}`}
                        >
                          Sign In
                        </button>
                        <button
                          id="tab_signup"
                          type="button"
                          onClick={() => { setIsRegistering(true); setAuthError(''); }}
                          className={`pb-1.5 px-3 transition-all ${isRegistering ? 'text-violet-400 border-b-2 border-violet-500' : 'text-slate-400 hover:text-white'}`}
                        >
                          Sign Up (Signup)
                        </button>
                      </div>
                    )}

                    {isRegistering && role === 'user' ? (
                      <form id="signup_cred_form" onSubmit={handleRegisterSubmit} className="space-y-3">
                        <div className="text-center pb-1">
                          <p className="text-[11px] text-slate-400">
                            Register now to claim an instant $0.15 premium node registration gift!
                          </p>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-400">Your Full Name</label>
                          <input
                            id="input_reg_name"
                            type="text"
                            required
                            placeholder="e.g. Siam Ahmed"
                            value={regName}
                            onChange={(e) => setRegName(e.target.value)}
                            className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-sm focus:outline-none focus:border-violet-500 font-sans text-white placeholder-slate-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-400">Bangladeshi Phone Number</label>
                          <input
                            id="input_reg_phone"
                            type="text"
                            placeholder="e.g. 01712345678"
                            value={regPhone}
                            onChange={(e) => setRegPhone(e.target.value)}
                            className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-sm focus:outline-none focus:border-violet-500 font-mono text-white placeholder-slate-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-400">Active Email Account</label>
                          <input
                            id="input_reg_email"
                            type="email"
                            placeholder="e.g. mail@dataearn.pro"
                            value={regEmail}
                            onChange={(e) => setRegEmail(e.target.value)}
                            className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-sm focus:outline-none focus:border-violet-500 font-mono text-white placeholder-slate-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase text-slate-400">Password / PIN code</label>
                          <input
                            id="input_reg_password"
                            type="password"
                            required
                            placeholder="Min 4 numbers/keys"
                            value={regPassword}
                            onChange={(e) => setRegPassword(e.target.value)}
                            className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-sm focus:outline-none focus:border-violet-500 text-white tracking-widest font-mono"
                          />
                        </div>

                        {authError && (
                          <div className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-red-400 text-xs flex items-start gap-2">
                            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                            <span>{authError}</span>
                          </div>
                        )}

                        <button
                          id="btn_signup_submit"
                          type="submit"
                          disabled={isLoggingIn}
                          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-500 hover:from-violet-500 text-white font-bold text-xs tracking-wider shadow-lg shadow-violet-900/30 transition-all flex items-center justify-center gap-2"
                        >
                          {isLoggingIn ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
                          Register & Get Bonus
                        </button>
                      </form>
                    ) : authStep === 'login' ? (
                      <form id="login_cred_form" onSubmit={handleLoginSubmit} className="space-y-3.5">
                          <div className="text-center pb-2">
                            <p className="text-xs text-slate-400">
                              {role === 'admin' 
                                ? "Enterprise authorization level security verification required."
                                : "Monetize extra Wi-Fi bandwidth seamlessly on South Asia's gold standard node."}
                            </p>
                          </div>

                          {role === 'user' ? (
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase text-slate-400">Phone Number or Email</label>
                              <input
                                id="input_user_identifier"
                                type="text"
                                required
                                placeholder="e.g. +8801712345678"
                                value={phone || email}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val.includes('@')) {
                                    setEmail(val);
                                    setPhone('');
                                  } else {
                                    setPhone(val);
                                    setEmail('');
                                  }
                                }}
                                className="w-full px-4 py-3 rounded-xl bg-slate-800/80 border border-slate-700 text-sm focus:outline-none focus:border-violet-500 font-mono text-white placeholder-slate-500"
                              />
                            </div>
                          ) : (
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase text-slate-400">Admin Phone Number or Email</label>
                              <input
                                id="input_admin_identifier"
                                type="text"
                                required
                                placeholder="e.g. 01781113140 or admin@dataearn.pro"
                                value={phone || email}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val.includes('@')) {
                                    setEmail(val);
                                    setPhone('');
                                  } else {
                                    setPhone(val);
                                    setEmail('');
                                  }
                                }}
                                className="w-full px-4 py-3 rounded-xl bg-slate-850/80 border border-slate-700 text-sm focus:outline-none focus:border-amber-500 font-mono text-white placeholder-slate-500"
                              />
                            </div>
                          )}

                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-slate-400">PasswordPIN Secret</label>
                            <input
                              id="input_auth_password"
                              type="password"
                              required
                              placeholder="Password PIN"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl bg-slate-800/80 border border-slate-700 text-sm focus:outline-none focus:border-violet-500 text-white tracking-widest font-mono"
                            />
                          </div>

                          {authError && (
                            <div className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-red-400 text-xs flex items-start gap-2">
                              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                              <span>{authError}</span>
                            </div>
                          )}

                          <button
                            id="btn_auth_submit"
                            type="submit"
                            disabled={isLoggingIn}
                            className={`w-full py-3 rounded-xl font-bold text-sm tracking-wide shadow-lg transition-all flex items-center justify-center gap-2 ${
                              role === 'admin'
                                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 text-white shadow-amber-900/30'
                                : 'bg-gradient-to-r from-violet-600 to-purple-500 hover:from-violet-500 text-white shadow-violet-900/30'
                            }`}
                          >
                            {isLoggingIn ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
                            {role === 'admin' ? "Proceed securely" : "Access sharing grid"}
                          </button>
                        </form>
                      ) : (
                        /* STEP B: OTP OR 2FA CONFIRMATION SYSTEM */
                        <form id="otp_verification_form" onSubmit={handleVerifyOtpSubmit} className="space-y-4">
                          <div className="text-center">
                            <h3 className="text-sm font-bold text-slate-200">
                              {role === 'admin' ? "2FA Verification Code" : "Phone OTP Verification"}
                            </h3>
                            <p className="text-xs text-slate-400 mt-1">
                              An authentic physical verification pass is prompted payloaded. Check hints on left for code!
                            </p>
                          </div>

                        <div className="space-y-2">
                          <input
                            id="input_verification_otp"
                            type="text"
                            maxLength={6}
                            required
                            placeholder={role === 'admin' ? "Enter 123456" : "Enter 1234"}
                            value={otpCode}
                            onChange={(e) => setOtpCode(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl bg-slate-800/80 border border-violet-500/40 text-center text-lg font-bold letter font-mono tracking-widest text-violet-300 focus:outline-none focus:border-violet-500"
                          />
                        </div>

                        {authError && (
                          <div className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-red-400 text-xs text-center">
                            {authError}
                          </div>
                        )}

                        <button
                          id="btn_verify_otp_submit"
                          type="submit"
                          disabled={isLoggingIn}
                          className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-sm transition flex items-center justify-center gap-2"
                        >
                          {isLoggingIn ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
                          Verify Pincode
                        </button>

                        <button
                          id="btn_back_to_login"
                          type="button"
                          onClick={() => setAuthStep('login')}
                          className="w-full text-center text-xs text-slate-400 hover:text-white mt-1 py-1"
                        >
                          Change login account
                        </button>
                      </form>
                    )}
                  </div>

                  {/* Footnote */}
                  <div className="text-center text-[10px] text-slate-500 mt-4 leading-normal">
                    Secure Android authentication node layer in operation. Deployed securely on DataEarn Pro server.
                  </div>
                </div>
              ) : (

                /* ------------------------- STATE B: LOGGED IN USER INTERFACES ------------------------- */
                role === 'user' ? (
                  <div className="flex-1 flex flex-col justify-between">
                    
                    {/* User Panel Core View Swapper */}
                    <div className="flex-1 p-5 space-y-5">
                      
                      {/* USER NOTIFICATIONS ALERTER BANNER */}
                      {notifications.length > 0 && (
                        <div id="user_unread_alert_banner" className="bg-gradient-to-r from-amber-900/40 to-yellow-900/30 border border-amber-500/20 p-3 rounded-xl flex items-start gap-2">
                          <Bell className="h-4 w-4 text-amber-400 shrink-0 mt-0.5 animate-bounce" />
                          <div className="text-[11px] leading-relaxed select-none">
                            <span className="font-bold text-amber-300">Live Warning:</span> {notifications[0].message}
                          </div>
                        </div>
                      )}

                      {/* 1. USER SUB PAGES (VIP plans / Reward Center / withdraw_portal etc.) */}
                      {userSubPage === 'sharing_ctrl' ? (
                        <div id="sub_page_sharing_gateway" className="space-y-4 animate-fade-in text-xs">
                          {/* Page Title Navbar */}
                          <div className="flex items-center justify-between">
                            <button onClick={() => setUserSubPage(null)} className="text-[11px] text-violet-400 flex items-center gap-1 font-bold">
                              &larr; Back dashboard
                            </button>
                            <span className="font-bold uppercase tracking-wider text-violet-200">Shared Gateway Node</span>
                          </div>

                          <div className="p-5 rounded-2xl bg-[#1b1535] border border-violet-500/30 text-center relative overflow-hidden">
                            {/* Glow orb if active */}
                            {activeSession?.status === 'active' && (
                              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-emerald-500/10 rounded-full filter blur-xl animate-pulse-slow" />
                            )}
                            
                            <div className="relative z-10 space-y-4">
                              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                                activeSession?.status === 'active' 
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' 
                                  : 'bg-zinc-500/10 text-zinc-400 border border-zinc-500/20'
                              }`}>
                                {activeSession?.status === 'active' ? '● Sharing Traffic Live' : '● Node Offline'}
                              </span>

                              {/* Massive Dynamic upload counter graphics */}
                              <div className="py-2">
                                <p className="text-[10px] text-zinc-400 uppercase tracking-widest font-bold">TOTAL UPLOADED THIS SESSION</p>
                                <h1 className="text-4xl font-extrabold font-mono text-cyan-300 tracking-tight mt-1 counter-animate">
                                  {activeSession ? activeSession.dataSharedMb.toFixed(2) : '0.00' } <span className="text-lg">MB</span>
                                </h1>
                                <p className="text-emerald-400 text-xs mt-1 font-bold">
                                  Estimated value: +${activeSession ? activeSession.earningsUsd.toFixed(4) : '0.0000'}
                                </p>
                                <div className="text-[10px] text-slate-400 mt-2">
                                  Calibrated Hardware Speed: <span className="text-teal-400 font-mono font-bold">{user?.sharingSpeed || 1} Mbps</span>
                                </div>
                              </div>

                              {/* Toggle connection type */}
                              <div className="flex gap-2 justify-center py-1">
                                <button
                                  id="btn_conn_wifi"
                                  onClick={() => setConnectionType('WiFi')}
                                  disabled={activeSession?.status === 'active'}
                                  className={`px-3 py-1 rounded-lg text-[10px] font-semibold border transition ${
                                    connectionType === 'WiFi' ? 'bg-violet-600/30 border-violet-500 text-white font-bold' : 'bg-transparent border-slate-700 text-slate-400'
                                  }`}
                                >
                                  Wi-Fi Only
                                </button>
                                <button
                                  id="btn_conn_cellular"
                                  onClick={() => setConnectionType('Cellular')}
                                  disabled={activeSession?.status === 'active'}
                                  className={`px-3 py-1 rounded-lg text-[10px] font-semibold border transition ${
                                    connectionType === 'Cellular' ? 'bg-violet-600/30 border-violet-500 text-white font-bold' : 'bg-transparent border-slate-700 text-slate-400'
                                  }`}
                                >
                                  Mobile Plan (Grid shared)
                                </button>
                              </div>

                              {/* Sharing Action triggers */}
                              <div className="pt-2 flex justify-center gap-3">
                                {activeSession?.status !== 'active' ? (
                                  <button
                                    id="btn_session_start"
                                    onClick={startSharingNode}
                                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-white font-bold shadow-md shadow-emerald-950 flex items-center gap-2"
                                  >
                                    <Play className="h-4 w-4 fill-white" /> Start monetization
                                  </button>
                                ) : (
                                  <>
                                    <button
                                      id="btn_session_pause"
                                      onClick={pauseSharingNode}
                                      className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold flex items-center gap-1.5"
                                    >
                                      <Pause className="h-4 w-4" /> Pause
                                    </button>
                                    <button
                                      id="btn_session_stop"
                                      onClick={stopSharingNode}
                                      className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold flex items-center gap-1.5"
                                    >
                                      <Square className="h-4 w-4 fill-white" /> Stop
                                    </button>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Data usage Limiters */}
                          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-700/50 space-y-4">
                            <h3 className="font-bold flex items-center gap-1.5">
                              <Sliders className="h-4 w-4 text-violet-400" /> Auto-Sharing Limiters
                            </h3>
                            <div className="space-y-3">
                              <div className="space-y-1">
                                <div className="flex justify-between text-[11px] text-slate-400">
                                  <span>Daily Shared Target:</span>
                                  <span className="font-mono text-violet-300 font-bold">{dailyLimitMb} MB</span>
                                </div>
                                <input
                                  id="slider_daily_limit"
                                  type="range"
                                  min={100}
                                  max={5000}
                                  value={dailyLimitMb}
                                  onChange={(e) => setDailyLimitMb(parseInt(e.target.value))}
                                  className="w-full accent-violet-500"
                                />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between text-[11px] text-slate-400">
                                  <span>Monthly Shared Target:</span>
                                  <span className="font-mono text-violet-300 font-bold">{(monthlyLimitMb / 1024).toFixed(1)} GB</span>
                                </div>
                                <input
                                  id="slider_monthly_limit"
                                  type="range"
                                  min={1024}
                                  max={51200}
                                  value={monthlyLimitMb}
                                  onChange={(e) => setMonthlyLimitMb(parseInt(e.target.value))}
                                  className="w-full accent-violet-500"
                                />
                              </div>
                            </div>
                          </div>

                          {/* Live Packet Logs Output Console */}
                          <div className="bg-black/80 rounded-xl p-4 border border-zinc-800 font-mono text-[10px] space-y-1.5 shadow-inner">
                            <span className="text-[9px] text-[#22c55e] font-bold block pb-1 border-b border-zinc-800">// DEVICE LIVE TRAFFIC CONSOLE ACTIVE</span>
                            <div className="h-32 overflow-y-auto space-y-1 scrollbar-thin">
                              {sharingTrafficLogs.length === 0 ? (
                                <div className="text-zinc-500">Wait starting the node packet stream, packet logs output here...</div>
                              ) : (
                                sharingTrafficLogs.map((log, idx) => (
                                  <div key={idx} className="text-[#38bdf8] truncate">{log}</div>
                                ))
                              )}
                            </div>
                          </div>
                        </div>

                      ) : userSubPage === 'vip_club' ? (
                        <div id="sub_page_vip_club" className="space-y-4 animate-fade-in text-xs">
                          {/* Title Navbar */}
                          <div className="flex items-center justify-between">
                            <button onClick={() => { setUserSubPage(null); setVipMessage(''); setVipError(''); }} className="text-[11px] text-violet-400 flex items-center gap-1 font-bold">
                              &larr; Back dashboard
                            </button>
                            <span className="font-bold uppercase tracking-wider text-indigo-200">DataEarn VIP Club</span>
                          </div>

                          {vipMessage && (
                            <div className="p-3 bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs rounded-xl flex items-start gap-2 select-none">
                              <Sparkles className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{vipMessage}</span>
                            </div>
                          )}

                          {vipError && (
                            <div className="p-3 bg-red-950/70 border border-red-500/40 text-red-300 text-xs rounded-xl flex items-start gap-2 select-none">
                              <AlertTriangle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
                              <span>{vipError}</span>
                            </div>
                          )}

                          <div className="p-4 bg-gradient-to-r from-violet-600 to-indigo-600 rounded-xl text-white select-none shadow-md">
                            <h3 className="text-sm font-bold flex items-center gap-1.5">
                              <Sparkles className="h-4.5 w-4.5" /> High priority payout channels
                            </h3>
                            <p className="text-[10px] text-white/80 mt-1">
                              Increasing VIP class unlocks maximum network prioritizing multipliers, granting more payout commissions. You now reside in <span className="underline font-bold text-yellow-300 uppercase">{user?.vipPlanId} Level Plan</span>.
                            </p>
                          </div>

                          {/* Plans bento grid representation */}
                          <div className="grid grid-cols-1 gap-3">
                            {[
                              { id: "bronze", name: "Bronze Level", mult: "1.0x Base", price: 0, req: "Free Starting Plan", rate: `$${(configPricing.perGbPriceUsd).toFixed(2)}/GB`, color: "border-[#CD7F32]/40 bg-[#CD7F32]/5", icon: <Award className="h-5 w-5 text-[#CD7F32]" /> },
                              { id: "silver", name: "Silver Share", mult: "1.25x Extra", price: 3.00, req: "Upgrade Price: $3.00 balance", rate: `$${(configPricing.perGbPriceUsd * 1.25).toFixed(2)}/GB`, color: "border-slate-400/40 bg-slate-400/5", icon: <ShieldCheck className="h-5 w-5 text-slate-300" /> },
                              { id: "gold", name: "Gold Node", mult: "1.6x Super", price: 10.00, req: "Upgrade Price: $10.00 balance", rate: `$${(configPricing.perGbPriceUsd * 1.6).toFixed(2)}/GB`, color: "border-yellow-400/40 bg-yellow-400/5", icon: <Flame className="h-5 w-5 text-yellow-500" /> },
                              { id: "diamond", name: "Diamond Node Pro", mult: "2.2x Max", price: 25.00, req: "Upgrade Price: $25.00 balance", rate: `$${(configPricing.perGbPriceUsd * 2.2).toFixed(2)}/GB`, color: "border-cyan-400/40 bg-cyan-400/5", icon: <Gem className="h-5 w-5 text-cyan-400" /> },
                            ].map((p, idx) => (
                              <div key={idx} className={`p-4 rounded-xl border flex items-center justify-between transition-transform hover:scale-[1.01] ${p.color} ${user?.vipPlanId === p.id ? 'ring-2 ring-violet-500' : ''}`}>
                                <div className="flex items-center gap-3">
                                  <div className="p-2.5 rounded-lg bg-black/40">
                                    {p.icon}
                                  </div>
                                  <div>
                                    <h4 className="font-bold text-sm">{p.name}</h4>
                                    <p className="text-[10px] text-slate-400 mt-0.5">{p.req} -- Multiplier {p.mult}</p>
                                  </div>
                                </div>
                                <div className="text-right space-y-1.5 flex flex-col items-end justify-center">
                                  <span className="text-xs font-mono font-bold text-white bg-black/45 px-2 py-0.5 rounded-lg">{p.rate}</span>
                                  {user?.vipPlanId === p.id ? (
                                    <span className="block text-[9px] text-violet-400 font-bold uppercase mt-1">✓ Active Tier</span>
                                  ) : (
                                    <button
                                      id={`btn_upgrade_vip_${p.id}`}
                                      onClick={() => handleVipUpgrade(p.id)}
                                      className="block px-3 py-1.5 bg-violet-650 hover:bg-violet-500 text-white text-[9px] font-bold rounded-md transition hover:scale-102 active:scale-95 whitespace-nowrap"
                                    >
                                      Buy Plan (${p.price.toFixed(2)})
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                      ) : userSubPage === 'speed_booster' ? (
                        <div id="sub_page_speed_booster" className="space-y-4 animate-fade-in text-xs">
                          {/* Title Navbar */}
                          <div className="flex items-center justify-between">
                            <button onClick={() => { setUserSubPage(null); setSpeedMessage(''); setSpeedError(''); }} className="text-[11px] text-violet-400 flex items-center gap-1 font-bold">
                              &larr; Back dashboard
                            </button>
                            <span className="font-bold uppercase tracking-wider text-teal-300">Carrier Speed Calibrator</span>
                          </div>

                          {speedMessage && (
                            <div className="p-3 bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs rounded-xl flex items-start gap-2 select-none">
                              <Sparkles className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{speedMessage}</span>
                            </div>
                          )}

                          {speedError && (
                            <div className="p-3 bg-red-950/70 border border-red-500/40 text-red-300 text-xs rounded-xl flex items-start gap-2 select-none">
                              <AlertTriangle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
                              <span>{speedError}</span>
                            </div>
                          )}

                          <div className="p-4 bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl text-white select-none shadow-md">
                            <h3 className="text-sm font-bold flex items-center gap-1.5">
                              <Sliders className="h-4.5 w-4.5" /> Calibrate Network Speed
                            </h3>
                            <p className="text-[10px] text-white/80 mt-1">
                              By default, starting node operates at <span className="font-bold underline">1 Mbps</span>. Upgrading node carrier configuration allows matching high-frequency bandwidth allocations, granting significantly faster data transfers and increased earnings.
                            </p>
                            <div className="mt-2 text-xs font-mono bg-black/30 p-2 rounded-lg inline-block">
                              Current hardware speed: <span className="text-teal-300 font-bold">{user?.sharingSpeed || 1} Mbps</span>
                            </div>
                          </div>

                          {/* Speed plans bento grid representation */}
                          <div className="grid grid-cols-1 gap-3">
                            {speedPlans.map((p, idx) => (
                              <div 
                                key={idx} 
                                className={`p-4 rounded-xl border flex items-center justify-between transition-transform ${p.color} ${(user?.sharingSpeed || 1) === p.speedMbps ? 'ring-2 ring-teal-500 border-teal-500/40 bg-teal-500/10' : ''}`}
                              >
                                <div className="flex items-center gap-3">
                                  <div className="p-2.5 rounded-lg bg-black/40 text-teal-400 flex items-center justify-center font-bold">
                                    <TrendingUp className="h-5 w-5 text-teal-400" />
                                  </div>
                                  <div>
                                    <h4 className="font-bold text-xs tracking-wide text-slate-100 flex items-center gap-1.5">
                                      {p.name}
                                      {(user?.sharingSpeed || 1) === p.speedMbps && (
                                        <span className="text-[9px] bg-teal-500 text-black px-1.5 py-0.2 rounded-md font-extrabold uppercase">Active</span>
                                      )}
                                    </h4>
                                    <p className="text-[10px] text-slate-400 mt-0.5">{p.description}</p>
                                    <span className="inline-block mt-1 text-[9px] font-mono text-teal-400 font-bold">Priority Speed: {p.speedMbps} Mbps</span>
                                  </div>
                                </div>
                                <div className="text-right space-y-1.5 flex flex-col items-end justify-center">
                                  <span className="text-xs font-mono font-bold text-white bg-black/45 px-2 py-0.5 rounded-lg whitespace-nowrap">
                                    {p.priceUsd === 0 ? "Free Launch" : `$${p.priceUsd.toFixed(2)}`}
                                  </span>
                                  {(user?.sharingSpeed || 1) !== p.speedMbps && (
                                    <button
                                      id={`btn_upgrade_speed_${p.id}`}
                                      onClick={() => handleSpeedUpgrade(p.id)}
                                      className="block px-3 py-1.5 bg-teal-605 bg-teal-500 text-slate-950 text-[9px] font-extrabold rounded-md transition hover:scale-102 active:scale-95 whitespace-nowrap uppercase tracking-wider"
                                    >
                                      Upgrade
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                      ) : userSubPage === 'reward_hub' ? (
                        <div id="sub_page_reward_hub" className="space-y-4 animate-fade-in text-xs">
                          {/* Title Navbar */}
                          <div className="flex items-center justify-between">
                            <button onClick={() => setUserSubPage(null)} className="text-[11px] text-violet-400 flex items-center gap-1 font-bold">
                              &larr; Back dashboard
                            </button>
                            <span className="font-bold uppercase tracking-wider text-violet-200">Rewards & Campaigns</span>
                          </div>

                          {/* Daily Loyalty Rewards Check-In */}
                          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-700/50 space-y-3">
                            <h3 className="font-bold flex items-center gap-1.5 text-sm text-amber-400">
                              <Coins className="h-4.5 w-4.5" /> Daily Check-In Bonus
                            </h3>
                            <p className="text-[10px] text-slate-400">
                              Tap sign-in daily to claim $0.15 instantly. Grants free spinning turns to fuel balance growth.
                            </p>
                            <button
                              id="btn_claim_checkin"
                              onClick={claimCheckIn}
                              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs"
                            >
                              Claim daily loyalty rewards (+$0.15)
                            </button>
                          </div>

                          {/* Lucky Spin Wheel Dynamic System */}
                          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-700/50 space-y-4 text-center">
                            <h3 className="font-bold flex items-center justify-center gap-1.5 text-sm text-cyan-300">
                              <Sparkles className="h-4.5 w-4.5 text-cyan-300" /> Lucky Wheel Spin
                            </h3>
                            <p className="text-[10px] text-slate-400">
                              Free turns remaining: <span className="font-bold text-white font-mono">{rewardState?.spinsRemaining ?? 0} spins</span>
                            </p>

                            {/* Outer Spinning design graphic */}
                            <div className="relative w-40 h-40 mx-auto flex items-center justify-center">
                              <div className={`w-full h-full rounded-full border-4 border-dashed border-violet-500/50 flex items-center justify-center absolute transition-all duration-[2.5s] ease-out ${
                                spinning ? 'rotate-[1440deg] scale-95 border-emerald-500' : ''
                              }`}>
                                {/* Segment divisions */}
                                <div className="absolute inset-0 flex items-center justify-center uppercase font-mono font-bold text-[8px] text-violet-300">
                                  <span className="absolute -top-1 font-bold text-yellow-300">$5.00</span>
                                  <span className="absolute -bottom-1 font-bold">$0.05</span>
                                  <span className="absolute -left-1 rotate-90 font-bold">$1.00</span>
                                  <span className="absolute -right-1 -rotate-90 font-bold">$0.50</span>
                                </div>
                              </div>
                              {/* Spin button core overlay */}
                              <button
                                id="btn_click_spin_wheel"
                                disabled={spinning || (rewardState?.spinsRemaining ?? 0) <= 0}
                                onClick={triggerSpinLuckyWheel}
                                className={`w-16 h-16 rounded-full font-bold shadow-lg flex items-center justify-center z-10 select-none text-[10px] ${
                                  (rewardState?.spinsRemaining ?? 0) > 0 && !spinning
                                    ? 'bg-gradient-to-br from-cyan-400 to-violet-600 hover:scale-105 active:scale-95 text-white'
                                    : 'bg-zinc-800 text-zinc-400 cursor-not-allowed'
                                }`}
                              >
                                {spinning ? "ROLL..." : "SPIN NOW"}
                              </button>
                            </div>

                            {/* Rewards messages display alerts */}
                            {rewardClaimMessage && (
                              <div id="spin_outcome_text" className="p-3 rounded-lg bg-black/45 border border-violet-500/30 text-slate-200">
                                {rewardClaimMessage}
                              </div>
                            )}
                          </div>
                        </div>

                      ) : userSubPage === 'withdraw_portal' ? (
                        <div id="sub_page_withdraw_portal" className="space-y-4 animate-fade-in text-xs">
                          {/* Title Navbar */}
                          <div className="flex items-center justify-between">
                            <button onClick={() => setUserSubPage(null)} className="text-[11px] text-violet-400 flex items-center gap-1 font-bold">
                              &larr; Back dashboard
                            </button>
                            <span className="font-bold uppercase tracking-wider text-pink-300">Request payout withdrawal</span>
                          </div>

                          <div className="bg-[#18112d] p-4 rounded-xl border border-pink-500/20">
                            <p className="text-[11px] text-pink-300 font-bold">MONEY WITHDRAW LIMITS</p>
                            <p className="text-[10px] text-slate-400 mt-1">
                              Minimal cash out payout limit: <span className="font-bold text-white">$10.00 USD</span>. Payout releases instantly within 2-4 standard working hours. Current Withdrawable Main Balance: <span className="font-mono text-emerald-400 font-bold">${activeMainBalance.toFixed(2)}</span>
                            </p>
                          </div>

                          {/* Submission payment channel choices */}
                          <form id="withdraw_submission_form" onSubmit={handleSubmitWithdraw} className="space-y-3">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase text-slate-400">Select Payout Payer Method</label>
                              <div className="grid grid-cols-3 gap-2">
                                {['bKash', 'Nagad', 'Rocket', 'Binance Pay', 'USDT', 'Bank Transfer'].map((m, idx) => (
                                  <button
                                    key={idx}
                                    id={`withdraw_method_btn_${m}`}
                                    type="button"
                                    onClick={() => setWithdrawMethod(m as WithdrawMethod)}
                                    className={`py-2 rounded-lg text-[10px] font-bold border transition ${
                                      withdrawMethod === m ? 'bg-pink-600 border-pink-500 text-white' : 'bg-slate-900 border-slate-700 text-slate-400'
                                    }`}
                                  >
                                    {m}
                                  </button>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase text-slate-400">Withdrawal cash amount (USD)</label>
                              <input
                                id="input_withdraw_amount"
                                type="number"
                                required
                                placeholder="Minimum $10.00"
                                value={withdrawAmount}
                                onChange={(e) => setWithdrawAmount(e.target.value)}
                                className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase text-slate-400">Account details / Phone (e.g. bKash Number)</label>
                              <input
                                id="input_withdraw_account"
                                type="text"
                                required
                                placeholder="bKash/Nagad phone or crypto address"
                                value={withdrawAccount}
                                onChange={(e) => setWithdrawAccount(e.target.value)}
                                className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs"
                              />
                            </div>

                            {withdrawErr && (
                              <div className="p-2.5 bg-red-950/40 border border-red-500/20 text-red-400 rounded-lg">
                                {withdrawErr}
                              </div>
                            )}

                            {withdrawMessage && (
                              <div id="withdraw_success_alert" className="p-2.5 bg-emerald-950/40 border border-emerald-500/20 text-emerald-300 rounded-lg">
                                {withdrawMessage}
                              </div>
                            )}

                            <button
                              id="btn_withdraw_payout_submit"
                              type="submit"
                              className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 font-bold text-xs uppercase"
                            >
                              Initialize Request payout
                            </button>
                          </form>
                        </div>

                      ) : (
                        
                        /* 2. MAINSTREAM NAVIGATION HOME STATS TAB */
                        userActiveTab === 'home' ? (
                          <div id="user_home_tab_pane" className="space-y-5 select-none text-xs">
                            
                            {/* Premium Welcome Banner */}
                            <div className="flex items-center justify-between">
                              <div>
                                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Passive Node active</span>
                                <h2 className="text-xl font-extrabold tracking-tight font-display text-white">{user?.name}</h2>
                              </div>
                              <span className="px-2 py-0.5 rounded bg-black/45 text-[10px] font-mono text-indigo-400 border border-violet-500/20 uppercase font-bold">
                                {user?.vipPlanId} node priority
                              </span>
                            </div>

                            {/* Sliding Promo Admin Banner */}
                            {adminBanners.length > 0 && (
                              <div className="relative h-28 rounded-2xl overflow-hidden shadow-lg shadow-violet-950 bg-cover bg-center" style={{ backgroundImage: `url(${adminBanners[0].url})` }}>
                                <div className="absolute inset-0 bg-black/75 flex flex-col justify-end p-3">
                                  <span className="text-[9px] font-bold text-violet-400 uppercase tracking-widest bg-violet-600/20 px-2 py-0.5 rounded-full w-fit mb-1">PROMOTION</span>
                                  <h4 className="text-[11px] font-bold text-white leading-normal">{adminBanners[0].title}</h4>
                                </div>
                              </div>
                            )}

                            {/* Main balance card statistics */}
                            <div className="bg-[#16122d]/80 rounded-2xl border border-violet-500/25 p-5 relative overflow-hidden shadow-md">
                              <span className="text-[10px] tracking-wider text-violet-300 font-bold uppercase">Main Cash Account Balance</span>
                              <div className="flex items-baseline justify-between mt-1">
                                <h1 className="text-3xl font-black font-mono tracking-tight text-white counter-animate" id="lbl_user_main_balance">
                                  ${activeMainBalance.toFixed(3)}
                                </h1>
                                <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-white font-mono font-bold">BDT {((wallet?.mainBalance ?? 0) * 118).toLocaleString('en-US', {maximumFractionDigits:0})} ৳</span>
                              </div>

                              <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-violet-500/15 text-[10px]">
                                <div>
                                  <span className="block text-slate-400">Total earned:</span>
                                  <span className="font-bold text-slate-200 font-mono">${earnings?.totalEarnings?.toFixed(2) ?? '0.00'}</span>
                                </div>
                                <div>
                                  <span className="block text-slate-400">Withdrawable:</span>
                                  <span className="font-bold text-emerald-400 font-mono">${wallet?.withdrawableBalance?.toFixed(2) ?? '0.00'}</span>
                                </div>
                              </div>
                            </div>

                            {/* Sub Shared stats list */}
                            <div className="grid grid-cols-2 gap-3 text-xs">
                              <div className="bg-slate-900/40 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between h-[80px]">
                                <span className="text-slate-400 text-[10px]">SHARED DATA (GB)</span>
                                <h3 className="text-base font-bold font-mono text-cyan-300 mt-1">{earnings?.totalSharedData?.toFixed(2) ?? '0.00'} GB</h3>
                              </div>
                              <div className="bg-slate-900/40 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between h-[80px]">
                                <span className="text-slate-400 text-[10px]">VIP MULTIPLIER</span>
                                <h3 className="text-base font-bold font-mono text-[#FFD700] mt-1">
                                  {user?.vipPlanId === 'diamond' ? '2.2x max' : user?.vipPlanId === 'gold' ? '1.6x super' : user?.vipPlanId === 'silver' ? '1.25x' : '1.0x'}
                                </h3>
                              </div>
                            </div>

                            {/* Carrier Speed Calibration Card */}
                            <div className="p-4 rounded-xl border border-teal-500/20 bg-teal-950/20 flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="p-2.5 rounded-xl bg-teal-950/80 text-teal-400">
                                  <Sliders className="h-5 w-5 text-teal-400" />
                                </div>
                                <div className="text-left">
                                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Node sharing speed</span>
                                  <p className="text-sm font-bold text-slate-100 flex items-center gap-1.5 mt-0.5">
                                    {user?.sharingSpeed || 1} Mbps Carrier Rate
                                    <span className="text-[9px] bg-teal-500/20 text-teal-300 border border-teal-500/30 px-1.5 py-0.2 rounded font-mono uppercase font-extrabold animate-pulse">Online</span>
                                  </p>
                                </div>
                              </div>
                              <button
                                id="btn_goto_speed_booster"
                                onClick={() => setUserSubPage('speed_booster')}
                                className="px-3 py-1.5 bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-950 text-[10px] font-extrabold rounded-lg tracking-wider uppercase hover:scale-102 transition"
                              >
                                Buy Speed
                              </button>
                            </div>

                            {/* QUICK ACTIONS BENTO GRID */}
                            <div className="space-y-2">
                              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Quick sharing features</p>
                              <div className="grid grid-cols-4 gap-2">
                                <button
                                  id="quick_action_sharing"
                                  onClick={() => setUserSubPage('sharing_ctrl')}
                                  className="p-2.5 rounded-xl bg-violet-600 text-white hover:bg-violet-500 flex flex-col items-center justify-center gap-1.5 transition text-center shadow-md shadow-violet-950"
                                >
                                  <RefreshCw className="h-4.5 w-4.5" />
                                  <span className="text-[10px] font-bold block leading-none">Share</span>
                                </button>
                                <button
                                  id="quick_action_vip"
                                  onClick={() => setUserSubPage('vip_club')}
                                  className="p-2.5 rounded-xl bg-slate-900 text-slate-200 border border-slate-800 hover:border-violet-500 hover:bg-violet-600/10 flex flex-col items-center justify-center gap-1.5 transition text-center"
                                >
                                  <Award className="h-4.5 w-4.5 text-yellow-500" />
                                  <span className="text-[10px] font-bold block leading-none">VIP VIP</span>
                                </button>
                                <button
                                  id="quick_action_rewards"
                                  onClick={() => setUserSubPage('reward_hub')}
                                  className="p-2.5 rounded-xl bg-slate-900 text-slate-200 border border-slate-800 hover:border-violet-500 hover:bg-violet-600/10 flex flex-col items-center justify-center gap-1.5 transition text-center"
                                >
                                  <Coins className="h-4.5 w-4.5 text-amber-500" />
                                  <span className="text-[10px] font-bold block leading-none">Rewards</span>
                                </button>
                                <button
                                  id="quick_action_withdraw"
                                  onClick={() => setUserSubPage('withdraw_portal')}
                                  className="p-2.5 rounded-xl bg-slate-900 text-slate-200 border border-slate-800 hover:border-violet-500 hover:bg-violet-600/10 flex flex-col items-center justify-center gap-1.5 transition text-center"
                                >
                                  <Wallet className="h-4.5 w-4.5 text-pink-500" />
                                  <span className="text-[10px] font-bold block leading-none">Payout</span>
                                </button>
                              </div>
                            </div>
                          </div>

                        ) : userActiveTab === 'earnings' ? (
                          /* TAB B: DEEP EARNINGS HISTORY PAGE */
                          <div id="user_earnings_pane" className="space-y-4 animate-fade-in text-xs select-none">
                            <h3 className="font-bold text-sm tracking-widest text-slate-300">Earnings stats history</h3>
                            
                            {/* Graphic Chart simulation with custom SVGs */}
                            <div className="bg-[#16122d]/70 rounded-xl p-4 border border-violet-500/20 space-y-4">
                              <span className="text-[11px] font-semibold text-slate-400 uppercase">Weekly progress chart</span>
                              
                              <div className="h-28 flex items-end justify-between px-2 pt-2 border-b border-violet-500/20">
                                {[
                                  { day: "Mon", height: "30%", val: "$0.85" },
                                  { day: "Tue", height: "55%", val: "$1.40" },
                                  { day: "Wed", height: "40%", val: "$1.10" },
                                  { day: "Thu", height: "75%", val: "$1.95" },
                                  { day: "Fri", height: "90%", val: "$2.35" },
                                  { day: "Sat", height: "50%", val: "$1.30" },
                                  { day: "Sun", height: "65%", val: "$1.70" }
                                ].map((b, idx) => (
                                  <div key={idx} className="flex flex-col items-center gap-1.5 w-[11%]">
                                    <span className="text-[9px] text-[#22c55e] font-mono leading-none">{b.val}</span>
                                    <div className="w-full bg-gradient-to-t from-violet-600 to-indigo-500 rounded-t-md transition-all duration-500 hover:opacity-85" style={{ height: b.height }} />
                                    <span className="text-[9px] text-slate-400 mt-1 uppercase font-bold">{b.day}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Earnings breakdown totals list */}
                            <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-700/50 space-y-3">
                              <div className="flex justify-between font-mono">
                                <span className="text-slate-400">Today Node Earnings:</span>
                                <span className="text-white font-bold">${earnings?.todayEarnings?.toFixed(2) ?? '0.00'}</span>
                              </div>
                              <div className="flex justify-between font-mono">
                                <span className="text-slate-400">Total historical shared:</span>
                                <span className="text-white font-bold">{earnings?.totalSharedData?.toFixed(2) ?? '0.00'} GB</span>
                              </div>
                              <div className="flex justify-between font-mono">
                                <span className="text-slate-400">Referral Commissions:</span>
                                <span className="text-[#a78bfa] font-bold">${referrals?.referralEarnings?.toFixed(2) ?? '0.00'}</span>
                              </div>
                            </div>
                          </div>

                        ) : userActiveTab === 'wallet' ? (
                          /* TAB C: DETAILED WALLET PAGE */
                          <div id="user_wallet_pane" className="space-y-4 animate-fade-in text-xs select-none">
                            <div className="flex items-center justify-between">
                              <h3 className="font-bold text-sm tracking-widest text-slate-300">Wallet ledger</h3>
                              <button onClick={() => setUserSubPage('withdraw_portal')} className="px-3 py-1 bg-pink-600 text-white rounded-lg text-[10px] font-bold">
                                Request payout
                              </button>
                            </div>

                            <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-4">
                              <div className="grid grid-cols-3 gap-2">
                                <div className="p-2 bg-black/45 rounded-lg">
                                  <span className="text-slate-400 text-[10px] block font-semibold leading-normal">Main Cash</span>
                                  <span className="font-bold text-slate-100 font-mono block text-sm mt-0.5">${wallet?.mainBalance?.toFixed(2) ?? '0.00'}</span>
                                </div>
                                <div className="p-2 bg-black/45 rounded-lg">
                                  <span className="text-slate-400 text-[10px] block font-semibold leading-normal">Pending</span>
                                  <span className="font-bold text-amber-400 font-mono block text-sm mt-0.5">${wallet?.pendingBalance?.toFixed(2) ?? '0.00'}</span>
                                </div>
                                <div className="p-2 bg-black/45 rounded-lg">
                                  <span className="text-slate-400 text-[10px] block font-semibold leading-normal">Cleared</span>
                                  <span className="font-bold text-emerald-400 font-mono block text-sm mt-0.5">${wallet?.withdrawableBalance?.toFixed(2) ?? '0.00'}</span>
                                </div>
                              </div>
                            </div>

                            {/* Transaction Ledger Records list */}
                            <div className="space-y-2">
                              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Transaction Statements</p>
                              <div className="space-y-2 max-h-[220px] overflow-y-auto scrollbar-thin">
                                {transactions.length === 0 ? (
                                  <div className="text-zinc-500 text-center py-6">No historical records logged in wallet database.</div>
                                ) : (
                                  transactions.map((tx, idx) => (
                                    <div key={idx} className="p-3 bg-slate-900/40 rounded-xl border border-slate-800 flex items-center justify-between">
                                      <div className="space-y-0.5">
                                        <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider ${
                                          tx.type.includes('withdraw') ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                        }`}>{tx.type}</span>
                                        <h4 className="text-[10.5px] font-bold text-slate-200 mt-1">{tx.description}</h4>
                                        <span className="text-[9px] text-slate-400 font-mono block">{new Date(tx.createdAt).toLocaleString()}</span>
                                      </div>
                                      <span className={`font-mono font-bold text-xs ${tx.type.includes('withdraw') ? 'text-red-400' : 'text-[#10b981]'}`}>
                                        {tx.type.includes('withdraw') ? '-' : '+'}${tx.amount.toFixed(2)}
                                      </span>
                                    </div>
                                  ))
                                )}
                              </div>
                            </div>
                          </div>

                        ) : userActiveTab === 'referral' ? (
                          /* TAB D: REFERRAL NETWORKS PANEL */
                          <div id="user_referral_pane" className="space-y-4 animate-fade-in text-xs select-none">
                            <h3 className="font-bold text-sm tracking-widest text-slate-300">Invite & Earn commissions</h3>
                            
                            <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-4">
                              <p className="text-[10px] leading-relaxed text-slate-400">
                                Share your personal code down, earn <span className="font-bold text-white">{configPricing.referralCommissionPercent}% direct commissions</span> whenever invited friends run a sharing node.
                              </p>

                              {/* Copy referral codes inputs widget */}
                              <div className="flex gap-2 p-1 bg-black/45 rounded-xl border border-slate-700/50">
                                <span className="flex-1 px-3 py-1.5 font-mono text-[11px] text-violet-300 font-bold self-center">
                                  EARN2283
                                </span>
                                <button
                                  id="btn_copy_referral_link"
                                  onClick={() => handleCopyLink(user?.referralCode || "EARN2283")}
                                  className="px-3 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 transition"
                                >
                                  {copiedText ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                                  {copiedText ? "Copied" : "Copy"}
                                </button>
                              </div>
                            </div>

                            {/* Referrals Statistics */}
                            <div className="p-3 bg-[#1b1535] rounded-xl border border-violet-500/20 text-center">
                              <div className="flex divide-x divide-violet-500/15">
                                <div className="flex-1">
                                  <span className="block text-[9px] text-slate-400 uppercase font-bold text-center">Total invited</span>
                                  <span className="font-mono font-bold text-lg text-white">{referrals?.referrals.length ?? 0} team</span>
                                </div>
                                <div className="flex-1">
                                  <span className="block text-[9px] text-slate-400 uppercase font-bold text-center">Referral profits</span>
                                  <span className="font-mono font-bold text-lg text-emerald-400">${referrals?.referralEarnings?.toFixed(2) ?? '0.00'}</span>
                                </div>
                              </div>
                            </div>

                            {/* Invited team network status table lists */}
                            <div className="space-y-2">
                              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active downstream team</p>
                              <div className="space-y-1.5 max-h-[160px] overflow-y-auto scrollbar-thin">
                                {referrals?.referrals.length === 0 ? (
                                  <div className="text-center text-zinc-500 py-4">No team nodes connected. Feel free to copy and share!</div>
                                ) : (
                                  referrals?.referrals.map((ref, idx) => (
                                    <div key={idx} className="p-3 bg-slate-900/40 rounded-xl border border-slate-800 flex items-center justify-between">
                                      <div className="space-y-0.5">
                                        <h4 className="font-semibold text-slate-200">{(ref as any).referredUser?.name}</h4>
                                        <span className="text-[9px] text-slate-400">{new Date(ref.createdAt).toLocaleDateString()}</span>
                                      </div>
                                      <span className="font-mono text-emerald-400 font-bold">+${ref.bonusEarned.toFixed(2)}</span>
                                    </div>
                                  ))
                                )}
                              </div>
                            </div>
                          </div>

                        ) : (
                          /* TAB E: Detiled profile configuration options */
                          <div id="user_profile_pane" className="space-y-4 animate-fade-in text-xs select-none">
                            <h3 className="font-bold text-sm tracking-widest text-slate-300 text-center uppercase">My Account Info</h3>

                            <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 flex items-center gap-3">
                              <div className="w-12 h-12 rounded-full border-2 border-violet-500 bg-slate-800 flex items-center justify-center font-bold text-lg select-none">
                                {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
                              </div>
                              <div>
                                <h4 className="font-bold text-sm text-slate-100">{user?.name}</h4>
                                <span className="text-[10px] text-violet-400 font-mono">{user?.phone || user?.email}</span>
                              </div>
                            </div>

                            <div className="bg-slate-900/60 rounded-xl border border-slate-800 divide-y divide-slate-800/65 overflow-hidden">
                              <div className="p-3 flex justify-between">
                                <span className="text-slate-400">Device Model ID:</span>
                                <span className="text-slate-200">{user?.deviceInfo || 'Android Simulated Emulator v14'}</span>
                              </div>
                              <div className="p-3 flex justify-between">
                                <span className="text-slate-400">Last authenticated login:</span>
                                <span className="text-slate-200 font-mono">{new Date(user?.lastLogin ?? Date.now()).toLocaleString()}</span>
                              </div>
                              <div className="p-3 flex justify-between">
                                <span className="text-slate-400 font-bold text-violet-400">Calibration security state:</span>
                                <span className="text-[#34d399] font-bold uppercase tracking-wider">✓ Device Secured</span>
                              </div>
                            </div>

                            {/* WhatsApp Support Option */}
                            <a
                              id="support_whatsapp_link"
                              href="https://wa.me/18063055082?text=Hello%20DataEarn%20Support%2C%20I%20need%20assistance%20with%20my%20account%20node."
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-full py-3.5 px-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/25 text-emerald-400 font-bold transition flex items-center justify-between hover:scale-[1.01]"
                            >
                              <div className="flex items-center gap-2.5">
                                <Phone className="h-4.5 w-4.5 text-emerald-400 shrink-0" />
                                <div className="text-left">
                                  <h4 className="font-bold text-xs text-slate-100">Live Support Help</h4>
                                  <span className="text-[10px] text-emerald-500/90 font-mono block">WhatsApp: +18063055082</span>
                                </div>
                              </div>
                              <span className="text-[9px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-md uppercase tracking-wider animate-pulse">Online</span>
                            </a>

                            {/* Exit dashboard button */}
                            <button
                              id="btn_panel_signout"
                              onClick={handleLogout}
                              className="w-full py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-red-400 font-bold transition text-center uppercase tracking-wide text-[10px]"
                            >
                              Disconnect current active node
                            </button>
                          </div>
                        )
                      )}
                    </div>

                    {/* FIXED BOTTOM NAVIGATION FOR CLIENT USERS */}
                    {!userSubPage && (
                      <nav id="user_bottom_nav_bar" className={`h-16 border-t font-sans px-2 flex justify-around items-center select-none ${
                        darkMode ? 'bg-[#0f0c1b]/95 border-slate-800' : 'bg-white border-slate-200'
                      }`}>
                        {[
                          { id: "home", label: "Home", icon: <Home className="h-4 w-4" /> },
                          { id: "earnings", label: "Earnings", icon: <TrendingUp className="h-4 w-4" /> },
                          { id: "wallet", label: "Wallet", icon: <Wallet className="h-4 w-4" /> },
                          { id: "referral", label: "Invite", icon: <Share2 className="h-4 w-4" /> },
                          { id: "profile", label: "Profile", icon: <User className="h-4 w-4" /> },
                        ].map((nav, idx) => (
                          <button
                            key={idx}
                            id={`user_nav_btn_${nav.id}`}
                            onClick={() => setUserActiveTab(nav.id as any)}
                            className={`flex flex-col items-center justify-center w-12 h-12 rounded-lg transition ${
                              userActiveTab === nav.id 
                                ? 'text-violet-500 font-extrabold scale-105' 
                                : 'text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            {nav.icon}
                            <span className="text-[9.5px] font-bold block mt-0.5 leading-none">{nav.label}</span>
                          </button>
                        ))}
                      </nav>
                    )}
                  </div>


                ) : (


                  /* ------------------------- STATE C: LOGGED IN ADMIN COMMAND PORTS ------------------------- */
                  <div className="flex-1 flex flex-col justify-between">
                    
                    {/* Admin Dashboard Active Segment views */}
                    <div className="flex-1 p-5 space-y-5">
                      
                      {adminActiveTab === 'dashboard' ? (
                        <div id="admin_dashboard_pane" className="space-y-4 animate-fade-in text-xs select-none">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-[9px] text-amber-500 font-bold uppercase tracking-widest block font-brand">Security Command Console</span>
                              <h2 className="text-lg font-black text-slate-100 font-display">System Statistics</h2>
                            </div>
                            <span className="px-2 py-0.5 bg-amber-600/10 text-amber-500 text-[10px] font-mono border border-amber-500/30 rounded uppercase font-bold">Admin Active</span>
                          </div>

                          {/* 2x2 Grid stats elements */}
                          <div className="grid grid-cols-2 gap-3">
                            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 space-y-2">
                              <span className="text-slate-400 text-[10px]">TOTAL NODE CLIENTS</span>
                              <h3 className="text-xl font-bold font-mono text-white" id="admin_stat_total_users">{adminMetrics?.metrics?.totalUsers ?? 6} active</h3>
                            </div>
                            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 space-y-2">
                              <span className="text-slate-400 text-[10px]">SHARING SESSIONS</span>
                              <h3 className="text-xl font-bold font-mono text-emerald-400" id="admin_stat_active_sessions">● {adminMetrics?.metrics?.activeSharingSessionsCount ?? 1} node</h3>
                            </div>
                            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 space-y-2 col-span-2">
                              <span className="text-slate-400 text-[10px] block">TOTAL BANDWIDTH PROXIED</span>
                              <h3 className="text-2xl font-bold font-mono text-cyan-300 mt-1">{adminMetrics?.metrics?.totalSharedDataGb ?? 15430} GB volume</h3>
                            </div>
                          </div>

                          {/* Admin announcement ticker poster */}
                          <form id="admin_broadcast_notification_form" onSubmit={handlePostAnnouncement} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                            <h4 className="font-semibold text-slate-300">Broadcast notification update alert</h4>
                            <div className="space-y-2">
                              <textarea
                                id="admin_announcement_input"
                                placeholder="E.g. Database updates completed successfully!"
                                value={announcementInput}
                                onChange={(e) => setAnnouncementInput(e.target.value)}
                                className="w-full h-14 bg-black/60 border border-slate-700 text-xs rounded-lg p-2 text-white"
                              />
                            </div>
                            <button type="submit" className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-[10px]">
                              Broadcasting warning banners
                            </button>
                          </form>
                        </div>


                      ) : adminActiveTab === 'users' ? (
                        /* ADMIN MANAGEMENT PORTAL: SEARCH USER ACCOUNTS AND PERFORM ACTIONS */
                        <div id="admin_users_pane" className="space-y-4 animate-fade-in text-xs select-none">
                          <h3 className="font-bold text-sm tracking-widest text-[#d97706]">Client Accounts Database</h3>
                          
                          {/* Search filters search users */}
                          <div className="flex gap-2 p-1 bg-black/45 rounded-lg border border-slate-800">
                            <Search className="h-4.5 w-4.5 text-zinc-500 self-center ml-2 shrink-0" />
                            <input
                              id="admin_user_search_field"
                              type="text"
                              placeholder="Search via phone or email matches..."
                              value={adminSearchQuery}
                              onChange={(e) => {
                                setAdminSearchQuery(e.target.value);
                                fetchAdminData();
                              }}
                              className="w-full px-2 py-1.5 bg-transparent border-0 text-white text-xs focus:outline-none"
                            />
                          </div>

                          {/* Users elements mapped inside inner list */}
                          <div className="space-y-2 max-h-[340px] overflow-y-auto scrollbar-thin">
                            {adminUsers.length === 0 ? (
                              <div className="text-center text-zinc-500 py-6">No matching user credentials found in database.</div>
                            ) : (
                              adminUsers.map((u, idx) => (
                                <div key={idx} className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 space-y-3">
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <h4 className="font-bold text-slate-100">{u.name}</h4>
                                      <p className="text-[10px] text-slate-400 font-mono mt-0.5">{u.phone ?? u.email}</p>
                                    </div>
                                    <span className={`px-2 py-0.5 text-[8px] font-bold rounded uppercase tracking-wider ${
                                      u.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                                    }`}>{u.status}</span>
                                  </div>

                                  <div className="grid grid-cols-2 text-[9px] text-slate-400 font-mono pb-2 border-b border-white/5">
                                    <div>Wallet Cash: <span className="font-bold text-emerald-400">${u.wallet?.mainBalance?.toFixed(2) ?? '0.00'}</span></div>
                                    <div>Total Shared: <span className="font-bold text-cyan-300">{(u.earningsSum?.totalSharedData ?? 0).toFixed(1)} GB</span></div>
                                  </div>

                                  {/* Control Buttons */}
                                  <div className="flex justify-end gap-1.5 pt-1">
                                    <button
                                      id={`btn_activate_user_${u.id}`}
                                      disabled={u.status === 'active'}
                                      onClick={() => handleUserStatusChange(u.id, 'active')}
                                      className="px-2 py-1 bg-emerald-600/20 text-[#34d399] rounded text-[9px] hover:bg-emerald-600/30 transition disabled:opacity-40"
                                    >
                                      Run Active
                                    </button>
                                    <button
                                      id={`btn_suspend_user_${u.id}`}
                                      disabled={u.status === 'suspended'}
                                      onClick={() => handleUserStatusChange(u.id, 'suspended')}
                                      className="px-2 py-1 bg-amber-600/20 text-amber-500 rounded text-[9px] hover:bg-amber-600/30 transition disabled:opacity-40"
                                    >
                                      Suspend
                                    </button>
                                    <button
                                      id={`btn_ban_user_${u.id}`}
                                      disabled={u.status === 'banned'}
                                      onClick={() => handleUserStatusChange(u.id, 'banned')}
                                      className="px-2 py-1 bg-red-600/20 text-red-500 rounded text-[9px] hover:bg-red-600/30 transition disabled:opacity-40"
                                    >
                                      Ban
                                    </button>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        </div>


                      ) : adminActiveTab === 'withdrawals' ? (
                        /* ADMIN PAYOUT TRANSACTIONS CONTROLLER: APPROVE OR REJECT PAYROLL */
                        <div id="admin_withdraws_pane" className="space-y-4 animate-fade-in text-xs select-none">
                          <h3 className="font-bold text-sm tracking-widest text-[#d97706]">Pending payout approvals</h3>
                          
                          <div className="space-y-2.5 max-h-[380px] overflow-y-auto scrollbar-thin">
                            {adminWithdrawals.length === 0 ? (
                              <div className="text-center text-zinc-500 py-6">All payout pipelines clear. No pending withdrawals logs.</div>
                            ) : (
                              adminWithdrawals.map((w, idx) => (
                                <div key={idx} className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-800 space-y-3">
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <span className="text-[10px] text-slate-400 block font-bold">REMIT ACCOUNT CREDS:</span>
                                      <code className="text-white bg-black/45 px-2 py-1 rounded text-[10px] font-mono mt-1 block w-fit">{w.accountDetails}</code>
                                    </div>
                                    <span className="text-sm font-bold font-mono text-pink-300">${w.amount.toFixed(2)}</span>
                                  </div>

                                  <div className="text-[10px] text-slate-400 space-y-0.5">
                                    <div>Payer System Route: <span className="text-white font-bold">{w.method}</span></div>
                                    <div>Associated profile: <span className="text-slate-300 font-bold">{w.user?.name || "Independent sharer"}</span></div>
                                    <div>Submission logged: <span className="font-mono">{new Date(w.createdAt).toLocaleString()}</span></div>
                                    <div>State indicator: <span className="font-bold text-amber-500 uppercase">{w.status}</span></div>
                                  </div>

                                  {/* Approve Reject payroll triggers list */}
                                  {w.status === 'pending' && (
                                    <div className="flex justify-end gap-2 pt-1 border-t border-white/5">
                                      <button
                                        id={`btn_payout_reject_${w.id}`}
                                        onClick={() => handleWithdrawalAction(w.id, 'reject')}
                                        className="px-3 py-1.5 bg-red-650 hover:bg-red-700 text-white rounded-lg text-[9px] font-bold"
                                      >
                                        Decline Refund
                                      </button>
                                      <button
                                        id={`btn_payout_approve_${w.id}`}
                                        onClick={() => handleWithdrawalAction(w.id, 'approve')}
                                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[9px] font-bold"
                                      >
                                        Verify & Release
                                      </button>
                                    </div>
                                  )}
                                </div>
                              ))
                            )}
                          </div>
                        </div>


                      ) : adminActiveTab === 'analytics' ? (
                        /* AUDIT TRAIL LOGS VIEWPORTS */
                        <div id="admin_analytics_pane" className="space-y-4 animate-fade-in text-xs select-none">
                          <h3 className="font-bold text-sm tracking-widest text-amber-500 flex items-center gap-1.5">
                            <Activity className="h-4.5 w-4.5" /> Security audit trail loggers
                          </h3>

                          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-3">
                            <p className="text-[10px] text-slate-400 leading-normal">
                              Database keeps passive checks tracing anomalies such as multiple concurrent connections or VPN spofs. Action records are logged here.
                            </p>
                          </div>

                          <div className="space-y-2 max-h-[300px] overflow-y-auto scrollbar-thin">
                            {adminLogs.map((log, idx) => (
                              <div key={idx} className="p-3 bg-slate-900/40 rounded-lg border border-slate-800 font-mono text-[9px] space-y-1">
                                <div className="flex justify-between font-bold text-slate-300">
                                  <span>[ACTION RECORD] -- {log.action}</span>
                                  <span className="text-zinc-500">{new Date(log.createdAt).toLocaleTimeString()}</span>
                                </div>
                                <div className="text-yellow-400 leading-normal">Details: {log.details}</div>
                                <div className="text-slate-500">Node IP target: {log.ip} -- OS: {log.device}</div>
                              </div>
                            ))}
                          </div>
                        </div>


                      ) : (
                        /* ADMIN SYSTEMS PRICING AND VALUE CONFIGURATION SATE */
                        <div id="admin_settings_pane" className="space-y-4 animate-fade-in text-xs select-none">
                          <h3 className="font-bold text-sm tracking-widest text-[#d97706]/95">Pricing Calibrations</h3>
                          
                          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-3">
                            <div className="space-y-1">
                              <label className="text-[10px] text-slate-400 uppercase font-bold">Standard Per MB Pricing (USD)</label>
                              <input
                                id="admin_mb_rate_input"
                                type="number"
                                step="0.00001"
                                value={configPricing.perMbPriceUsd}
                                onChange={(e) => setConfigPricing({ ...configPricing, perMbPriceUsd: parseFloat(e.target.value) })}
                                className="w-full px-3 py-2 bg-black border border-slate-700 text-white text-xs font-mono"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] text-slate-400 uppercase font-bold">Referral Commission percentages (%)</label>
                              <input
                                id="admin_commission_rate_input"
                                type="number"
                                value={configPricing.referralCommissionPercent}
                                onChange={(e) => setConfigPricing({ ...configPricing, referralCommissionPercent: parseFloat(e.target.value) })}
                                className="w-full px-3 py-2 bg-black border border-slate-700 text-white text-xs font-mono"
                              />
                            </div>

                            <button
                              id="btn_admin_save_rates"
                              onClick={handleSavePricingConfig}
                              className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-[10px]"
                            >
                              Save settings configurations
                            </button>
                          </div>

                          {/* Profile controls */}
                          <div className="pt-4 border-t border-slate-800">
                            <button
                              id="btn_admin_panel_signout"
                              onClick={handleLogout}
                              className="w-full py-2 bg-[#dc2626]/20 border border-red-950 text-red-400 hover:bg-red-900/30 text-xs font-bold rounded-xl"
                            >
                              Disconnect Administrator Secure Node
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* ADMIN NAVIGATION OPTIONS */}
                    <nav id="admin_bottom_nav_bar" className={`h-16 border-t font-sans px-2 flex justify-around items-center select-none ${
                      darkMode ? 'bg-[#121020] border-slate-800' : 'bg-white border-slate-200'
                    }`}>
                      {[
                        { id: "dashboard", label: "Stats", icon: <Home className="h-4 w-4" /> },
                        { id: "users", label: "Users DB", icon: <Users className="h-4 w-4" /> },
                        { id: "withdrawals", label: "Payouts", icon: <Wallet className="h-4 w-4 text-pink-500" /> },
                        { id: "analytics", label: "Security Logs", icon: <Activity className="h-4 w-4 text-[#ecc94b]" /> },
                        { id: "settings", label: "Rates", icon: <Settings className="h-4 w-4 text-[#c084fc]" /> },
                      ].map((nav, idx) => (
                        <button
                          key={idx}
                          id={`admin_nav_btn_${nav.id}`}
                          onClick={() => setAdminActiveTab(nav.id as any)}
                          className={`flex flex-col items-center justify-center w-12 h-12 rounded-lg transition ${
                            adminActiveTab === nav.id 
                              ? 'text-amber-500 font-extrabold scale-105' 
                              : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {nav.icon}
                          <span className="text-[9.5px] font-bold block mt-0.5 leading-none">{nav.label}</span>
                        </button>
                      ))}
                    </nav>

                  </div>
                )
              )}
            </div>

            {/* Simulated physical smartphone controls (Back button / Home pill bar) */}
            <div id="android_nav_bar" className="h-6 bg-black flex items-center justify-center relative select-none">
              <div id="android_home_pill" className="w-[120px] h-[4px] bg-[#64748b] rounded-full" />
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
